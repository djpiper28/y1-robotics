import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import emotions.Emotions;

public final class EmotionsTest {

	Emotions e;
	
	@Before
	public void testConstructor() {
		e = new Emotions();
	}
	
	@Test
	public void testDrawing() {
		
	}
	
}
