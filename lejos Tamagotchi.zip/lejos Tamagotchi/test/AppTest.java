import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

import org.junit.Test;

import common.EmotionPrimitiveID;
import common.EmotionsInterface;
import common.netty.messages.EmotionUpdateMessage;
import common.netty.messages.MessagesIOHandler;
import common.netty.messages.NotifyUserMessage;
import emotions.Emotions;
import spaghetti.netty.RobotBtConnection;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import common.EmotionPrimitiveID;
import common.EmotionsInterface;
import common.netty.messages.EmotionUpdateMessage;
import common.netty.messages.MessagesIOHandler;
import common.netty.messages.UserNotification;
import lejos.hardware.Bluetooth;
import lejos.hardware.lcd.LCD;
import lejos.remote.nxt.NXTCommConnector;
import lejos.remote.nxt.NXTConnection;

public class AppTest {

	@Test
	public void testApp() throws Exception {
		final String ip = "192.168.1.169";
		
		TestEmotions emotionsInterface = new TestEmotions();
		TestConn conn = new TestConn(emotionsInterface, ip);
		emotionsInterface.setNetty(conn);
		
		while (!conn.isConnected()) Thread.sleep(10);
		
		System.out.println("Test start");
		
		conn.startPollingThread();
		
		conn.sendMessage(new NotifyUserMessage(new UserNotification("Test start", "Testy mctestface")));
		
		for (float i = 0f; i <= 50f; i++) {
			emotionsInterface.setBoredem(i / 50f);
			emotionsInterface.setTired(i / 50f);
			emotionsInterface.setHunger(i / 50f);
			emotionsInterface.setFear(i / 50f);
			
			System.out.println(i / 50);
			
			Thread.sleep(250);
		}

		Random rand = new Random();

		emotionsInterface.setBoredem(rand.nextFloat());
		emotionsInterface.setTired(rand.nextFloat());
		emotionsInterface.setHunger(rand.nextFloat());
		emotionsInterface.setFear(rand.nextFloat());
		
		conn.sendMessage(new NotifyUserMessage(new UserNotification("Test end", "Testy mctestface")));
		
		System.out.println("Test end");
		
		conn.stopPollingThread();
		conn.disconnect();
	}

} class TestEmotions extends EmotionsInterface {

	private MessagesIOHandler netty;
	
	public TestEmotions() {
		super();
	}
	
	public void setNetty(MessagesIOHandler netty) {
		this.netty = netty;
	}
	
	@Override
	public void onHappinessSet(float newHappiness) {
	}

	@Override
	public void onCourageSet(float newCourage) {
		
	}
	
	@Override
	public void onCuriositySet(float newCuriosity) {
		
	}
	
	@Override
	public void onHungerSet(float newHunger) {
		if (netty != null) {
			try {
				this.netty.sendMessage(
						new EmotionUpdateMessage(EmotionPrimitiveID.HUNGER, newHunger));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onBordemSet(float newBoredom) {
		if (netty != null) {
			try {
				this.netty.sendMessage(
						new EmotionUpdateMessage(EmotionPrimitiveID.BOREDOM, newBoredom));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onTiredSet(float newTired) {
		if (netty != null) {
			try {
				this.netty.sendMessage(
						new EmotionUpdateMessage(EmotionPrimitiveID.TIRED, newTired));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void onFearSet(float newFear) {
		if (netty != null) {
			try {
				this.netty.sendMessage(
						new EmotionUpdateMessage(EmotionPrimitiveID.FEAR, newFear));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
} 

/**
 * This spaghetti netty will connect to the bluetooth device by waiting literal days 
 * for a connection then it will connect and do stuff.
 * @author danny
 * @version 1.0
 */
class TestConn extends MessagesIOHandler {
	
	private static final int PORT = 4200;
	private String ipAddr; 
	private boolean connected;
	private Socket socket;
	private InputStream is;
	private OutputStream os;
	//Should be correct honestly EV3 has too much spaghetti for some good netty
	
	public synchronized boolean isConnected() {
		return connected;
	}

	public synchronized void setConnected(boolean connected) {
		this.connected = connected;
	}
	
	/**
	 * Starts a thing to init a connection
	 * @param emotionsInterface -> interface to write/read to
	 * @since 1.0
	 */
	public TestConn(EmotionsInterface emotionsInterface, String ipAddr) {				
		super(emotionsInterface);
		this.connected = false;
		this.ipAddr = ipAddr;
		
		(new Thread () {
			@Override
			public void run() {
				connect();
			}
		}).start();
	}
	
	/**
	 * Connects to the bluetooth device over the native bt interface as opposed to a
	 * socket server which seems really spaghetti
	 * @since 1.0
	 */
	private synchronized void connect() {	
		try {	
			//This is complete spaghetti and I hate it so much
			this.socket = new Socket();
			SocketAddress sa = new InetSocketAddress(this.ipAddr, PORT);
		    
		    this.socket.connect(sa, 1500);
			this.is = this.socket.getInputStream();
			this.os = this.socket.getOutputStream();
			
			this.setIOStreams(is, os);
			this.connected = true;
								
			this.startPollingThread();

			this.sendMessage(new EmotionUpdateMessage(EmotionPrimitiveID.TIRED,
							this.emotionsInterface.getTired()));
			this.sendMessage(new EmotionUpdateMessage(EmotionPrimitiveID.BOREDOM,
							this.emotionsInterface.getBoredom()));
			this.sendMessage(new EmotionUpdateMessage(EmotionPrimitiveID.FEAR,
							this.emotionsInterface.getFear()));
			this.sendMessage(new EmotionUpdateMessage(EmotionPrimitiveID.HUNGER,
							this.emotionsInterface.getHunger()));
			
			System.out.println("Connected");
		} catch(IOException e) {
			e.printStackTrace();
			this.onIOException(e);
		}
	}

	/**
	 * DOES NOTHING AS THIS IS NEVER CALLED ON THE ROBOT
	 * @since 1.0
	 */
	@Override
	protected void onNotification(UserNotification notification) {
		//Do nothing as I am not a notifier		
	}

	/**
	 * Reconnects on error
	 * @param e -> error
	 * @since 1.0
	 */
	@Override
	protected synchronized void onIOException(IOException e) {
		//e.printStackTrace();
		
		try {
			this.disconnect();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		this.connect();		
	}

	@Override
	protected void onSignalStrength(double strength) {
		// TODO send it to a thing
		
	}
	
	/**
	 * DOES NOTHING AS THIS IS NEVER CALLED ON THE ROBOT
	 * @since 1.0
	 */
	@Override
	protected void onSignalStrengthReq() {
		//Do nothing for I request not respond
	}

	@Override
	protected void onDeathMessage() {
		//Do nothing as I am the death sender		
	}
	
	@Override
	protected void onCubeUpdate(byte[] data) {
		/**
		 *  idk - not my code
		 *  @author Danny
		 */
	}
	
	public synchronized void disconnect() throws IOException {
		this.connected = false;
		if (this.socket != null) this.socket.close();
	}

}
