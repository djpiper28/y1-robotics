import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import utils.Pilot;

public final class PilotTest {
	
	Pilot p;
	
	@Before
	public void testConstructor() {
		p = new Pilot();
	}
	
	@Test
	public void testForward() {
		p.move(50);
	}
	
	@Test
	public void testBackward() {
		p.move(-50);
	}
	
	@Test
	public void testRotate() {
		p.rotate(-500);
	}
	
	@Test
	public void testRotate2() {
		p.rotate(500);
	}
	
}