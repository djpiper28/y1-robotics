import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import graphics.ImageDrawer;

public final class ImageDrawerTest {
	ImageDrawer testDrawer;
	
	@Before
	public void testConstructor() throws IOException {
		testDrawer = new ImageDrawer(new BufferedInputStream(new FileInputStream("resources/test.png")));
	}
	
	@Test
	public void testDrawing() {
		testDrawer.drawImage(0, 0);
	}
}