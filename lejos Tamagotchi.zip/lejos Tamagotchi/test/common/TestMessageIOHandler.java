import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import org.junit.Test;

import common.EmotionsInterface;
import common.netty.messages.MessagesIOHandler;
import common.netty.messages.RobotDeathMessage;
import common.netty.messages.UserNotification;

public class TestMessageIOHandler {

	@Test
	public void test() throws IOException {
		EmotionsInterface emotions = new EmotionsInterface() {
			
			@Override
			public void onTiredSet(float newTired) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onHungerSet(float newHunger) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onHappinessSet(float newEmotion) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onFearSet(float newFear) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onCuriositySet(float newEmotion) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onCourageSet(float newEmotion) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onBordemSet(float newBordem) {
				// TODO Auto-generated method stub
				
			}
		};
				
		MessagesIOHandler a = new MessagesIOHandler(emotions) {			
			@Override
			protected void onSignalStrengthReq() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onSignalStrength(double strength) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onNotification(UserNotification notification) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onIOException(IOException e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onDeathMessage() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onCubeUpdate(byte[] data) {
				// TODO Auto-generated method stub
			}
		};
		
		ServerSocket server = new ServerSocket(6969);
		Socket recv = new Socket("0.0.0.0", 6969);
		Socket send = server.accept();
		
		a.setIOStreams(send.getInputStream(), send.getOutputStream());
		
		MessagesIOHandler b = new MessagesIOHandler(emotions) {				
			@Override
			protected void onSignalStrengthReq() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onSignalStrength(double strength) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onNotification(UserNotification notification) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onIOException(IOException e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onDeathMessage() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			protected void onCubeUpdate(byte[] data) {
				// TODO Auto-generated method stub
			}
		};
		
		b.setIOStreams(recv.getInputStream(), recv.getOutputStream());
		
		a.startPollingThread();
		b.startPollingThread();
		
		a.sendMessage(new RobotDeathMessage());
		b.sendMessage(new RobotDeathMessage());
		
		a.stopPollingThread();
		b.stopPollingThread();
		
		send.close();
		recv.close();
		server.close();
	}

}
