package common;

import java.io.IOException;
import java.util.Random;
import org.junit.Test;

import common.netty.messages.SignalStrengthMessage;

public class TestSigStrength {

	@Test
	public void	testSigStrength() throws IOException {
		final double a = (new Random()).nextDouble();
		assert((new SignalStrengthMessage()).fromBytes(new SignalStrengthMessage(a).getByteArray()) == a);
	}

}
