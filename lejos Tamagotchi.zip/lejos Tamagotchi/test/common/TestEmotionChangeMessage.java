package common;
import common.EmotionPrimitiveID;
import common.EmotionsInterface;
import common.netty.messages.EmotionUpdateMessage;

import java.io.IOException;
import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public final class TestEmotionChangeMessage {

	@Test
	public void testBasicCase() throws IOException {
		EmotionUpdateMessage message = new EmotionUpdateMessage(EmotionPrimitiveID.BOREDOM, 0.5f);
		byte[] data = message.getByteArray();
		
		EmotionUpdateMessage message2 = new EmotionUpdateMessage();

		testEmotionsInterface em = new testEmotionsInterface();
		message2.fromBytesArray(data, em);
		assert(em.getBoredom() == 0.5f);
	}
	
	@Test
	public void testOnRandomData() throws IOException {
		Random r = new Random();
		
		for(int i = 0; i < 1000000; i++) {
			float next = r.nextFloat();
			try {
				//Sterllise
				EmotionUpdateMessage  message = new EmotionUpdateMessage(EmotionPrimitiveID.BOREDOM, 
						next);
				byte[] testdata = message.getByteArray();
				
				if(testdata == null) {
					System.out.printf("[TEST/TestEmotionChangeMessage]: FAILED with float %f, i is %d\n", next, i);
					assert(testdata != null);
				}				
					
				//Reset object
				message = new EmotionUpdateMessage();
					
				//Desterlise
				testEmotionsInterface em = new testEmotionsInterface();
				message.fromBytesArray(testdata, em);
					
				assert(em.getBoredom() == next);
			} catch(Exception e) {
				e.printStackTrace();
				System.out.printf("Failed with x = %f\n", next);
			}
		}		
	}
	
	@Test(expected = NullPointerException.class)
	public void testNullArrayError() throws IOException {
		byte[] data = null;
		
		EmotionUpdateMessage message2 = new EmotionUpdateMessage();

		testEmotionsInterface em = new testEmotionsInterface();
		message2.fromBytesArray(data, em);
	}
	
	
	@Test(expected = IOException.class)
	public void testBadLengthData() throws IOException {
		EmotionUpdateMessage message = new EmotionUpdateMessage(EmotionPrimitiveID.BOREDOM, 0.5f);
		byte[] data = message.getByteArray();
		
		byte[] data2 = new byte[data.length - 1];
		for (int i = 0; i < data.length - 1; i++)
			data2[i] = data[i];
		
		EmotionUpdateMessage message2 = new EmotionUpdateMessage();

		testEmotionsInterface em = new testEmotionsInterface();
		message2.fromBytesArray(data2, em);
	}
	
	@Test(expected = IOException.class) 
	public void testBadHeader() throws IOException {
		EmotionUpdateMessage message = new EmotionUpdateMessage(EmotionPrimitiveID.BOREDOM, 0.5f);
		byte[] data = message.getByteArray();
		data[0] = (byte) 0xFF;
		
		EmotionUpdateMessage message2 = new EmotionUpdateMessage();

		testEmotionsInterface em = new testEmotionsInterface();
		message2.fromBytesArray(data, em);
		assert(em.getBoredom() == 0.5f);
	}
	
} 
class testEmotionsInterface extends EmotionsInterface {	
	
	public void onBordemSet(float newBordem) {}

	public void onCourageSet(float newEmotion) {}

	public void onCuriositySet(float newEmotion) {}

	public void onFearSet(float newFear) {}

	public void onHappinessSet(float newEmotion) {}

	public void onHungerSet(float newHunger) {}

	public void onTiredSet(float newTired) {}
	
}