package common;

import java.io.IOException;
import java.util.Random;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import common.netty.messages.NotifyUserMessage;
import common.netty.messages.UserNotification;

public class TestNotifyUserMessage {
	
	@Test
	public void testBasicCase() throws IOException {
		UserNotification testNotif = new UserNotification("Test1", "Test2");
		NotifyUserMessage test = new NotifyUserMessage(testNotif);
		
		byte[] data = test.getByteArray();
		
		NotifyUserMessage test2 = new NotifyUserMessage();
		UserNotification testNotif2 = new UserNotification("a", "b");
		test2.fromBytesArray(data, testNotif2);
		
		assert(test.equals(test2));
	}
	
	@Test
	public void testOnRandomData() throws IOException {
		Random rand = new Random();
		for (int i = 0; i < 250; i++) {					
			//get random test data
			int a = rand.nextInt(500), 
				b = rand.nextInt(500);
			
			char[] aa = new char[a],
				   bb = new char[b];
			
			//pop aa
			for (int j = 0; j < a; j++)
				aa[j] = (char) (rand.nextInt(255 - 32) + 32);
			
			//pop bb
			for (int j = 0; j < b; j++)
				bb[j] = (char) (rand.nextInt(255 - 32) + 32);
			
			String aaa = new String(aa), bbb = new String(bb);
			try {
				UserNotification testNotif = new UserNotification(aaa, bbb);
				NotifyUserMessage test = new NotifyUserMessage(testNotif);				
				byte[] data = test.getByteArray();
				
				NotifyUserMessage test2 = new NotifyUserMessage();
				UserNotification testNotif2 = new UserNotification("", "");
				test2.fromBytesArray(data, testNotif2);
				
				assert(testNotif.equals(testNotif2));
			} catch(Exception e) {
				e.printStackTrace();
				System.out.printf("Failed with strings : >>>%s<<< >>>%s<<<\n", aaa, bbb);
				throw e;
			}
		}
	}
	
	@Test (expected = IOException.class)
	public void testBadHeadersCase() throws IOException {
		byte[] data = new byte[3];
		
		NotifyUserMessage test2 = new NotifyUserMessage();
		UserNotification testNotif2 = new UserNotification("", "");
		test2.fromBytesArray(data, testNotif2);
	}

	@Test (expected = IOException.class)
	public void testBadLengthDecodeCase0() throws IOException {
		byte[] data = new byte[2];
		
		NotifyUserMessage test2 = new NotifyUserMessage();
		UserNotification testNotif2 = new UserNotification("", "");
		test2.fromBytesArray(data, testNotif2);
	}
	
	@Test (expected = IOException.class)
	public void testBadLengthDecodeCase1() throws IOException {
		NotifyUserMessage msg = new NotifyUserMessage(new UserNotification("a", "a"));
		byte[] data = msg.getByteArray();		
		byte[] data2 = new byte[data.length - 1];
		for (int i = 0; i < data.length - 1; i++)
			data2[i] = data[i];
		
		NotifyUserMessage test2 = new NotifyUserMessage();
		UserNotification testNotif2 = new UserNotification("a", "b");
		test2.fromBytesArray(data2, testNotif2);
	}
	
	@Test (expected = IOException.class)
	public void testBadLengthDecodeCase2() throws IOException {
		NotifyUserMessage msg = new NotifyUserMessage(new UserNotification("a", "a"));
		byte[] data = msg.getByteArray();		
		byte[] data2 = new byte[data.length + 1];
		for (int i = 0; i < data.length - 1; i++)
			data2[i] = data[i];
		
		NotifyUserMessage test2 = new NotifyUserMessage();
		UserNotification testNotif2 = new UserNotification("a", "b");
		test2.fromBytesArray(data2, testNotif2);
	}
	
}
