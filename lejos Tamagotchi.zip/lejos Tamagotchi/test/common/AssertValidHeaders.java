package common;

import org.junit.Test;

import common.netty.messages.MessageType;
import common.netty.messages.ResponseCode;

public class AssertValidHeaders {

	private final static byte MAX_NIBBLE = (byte) 0xff;
	
	@Test
	public void assertValidMessageTypes () {
		for (MessageType m: MessageType.values())
			assert (m.getTypeNibble() <= MAX_NIBBLE);
	}
	
	@Test
	public void assertValidRespCodes () {
		for (ResponseCode m: ResponseCode.values())
			assert (m.getReponseNibble() <= MAX_NIBBLE);
	}
}
