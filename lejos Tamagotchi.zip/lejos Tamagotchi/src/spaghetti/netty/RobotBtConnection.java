package spaghetti.netty;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import common.EmotionPrimitiveID;
import common.EmotionsInterface;
import common.netty.messages.EmotionUpdateMessage;
import common.netty.messages.MessagesIOHandler;
import common.netty.messages.UserNotification;
import behaviours.passive.RubiksCubeBehavior;
import spaghetti.netty.OnSigStrengthRecv;
import lejos.hardware.Bluetooth;
import lejos.hardware.lcd.LCD;

/**
 * This spaghetti netty will connect to the bluetooth device by waiting literal days 
 * for a connection then it will connect and do stuff.
 * @author danny
 * @version 1.0
 */
public class RobotBtConnection extends MessagesIOHandler {
	
	private static final int PORT = 4200;
	private String ipAddr = "10.0.1.4"; 
	private boolean connected;
	private Socket socket;
	private InputStream is;
	private OutputStream os;
	private RubiksCubeBehavior cubeBehavior;
	private OnSigStrengthRecv onSig;
	//Should be correct honestly EV3 has too much spaghetti for some good netty
	
	public synchronized boolean isConnected() {
		return connected;
	}

	public synchronized void setConnected(boolean connected) {
		this.connected = connected;
	}
	
	/**
	 * Starts a thing to init a connection
	 * @param emotionsInterface -> interface to write/read to
	 * @since 1.0
	 */
	public RobotBtConnection(EmotionsInterface emotionsInterface, String ipAddr, RubiksCubeBehavior cube) {				
		super(emotionsInterface);
		this.connected = false;
		this.ipAddr = ipAddr;
		this.cubeBehavior = cube;
		
		LCD.drawString("Disonnected", 0, 2);
		(new Thread () {
			@Override
			public void run() {
				connect();
			}
		}).start();
	}
	
	/**
	 * Connects to the bluetooth device over the native bt interface as opposed to a
	 * socket server which seems really spaghetti
	 * @since 1.0
	 */
	private synchronized void connect() {	
		try {	
			//This is complete spaghetti and I hate it so much
			this.socket = new Socket();
			SocketAddress sa = new InetSocketAddress(this.ipAddr, PORT);
		    this.socket.connect(sa, 1500);
			this.socket.setKeepAlive(true);
			this.is = this.socket.getInputStream();
			this.os = this.socket.getOutputStream();
						
			this.setIOStreams(is, os);
			this.connected = true;
			
			LCD.drawString("Connected   ", 0, 2);
					
			this.startPollingThread();

			(new Thread() {
				@Override
				public void run() {	
					try {							
						Thread.sleep(1000);
						sendMessage(new EmotionUpdateMessage(EmotionPrimitiveID.TIRED,
										emotionsInterface.getTired()));
						sendMessage(new EmotionUpdateMessage(EmotionPrimitiveID.BOREDOM,
										emotionsInterface.getBoredom()));
						sendMessage(new EmotionUpdateMessage(EmotionPrimitiveID.FEAR,
										emotionsInterface.getFear()));
						sendMessage(new EmotionUpdateMessage(EmotionPrimitiveID.HUNGER,
										emotionsInterface.getHunger()));
					} catch(IOException e) {
						onIOException(e);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}				
			}).start();
		} catch(IOException e) {
			this.onIOException(e);
		}
	}

	/**
	 * DOES NOTHING AS THIS IS NEVER CALLED ON THE ROBOT
	 * @since 1.0
	 */
	@Override
	protected void onNotification(UserNotification notification) {
		//Do nothing as I am not a notifier		
	}

	/**
	 * Reconnects on error
	 * @param e -> error
	 * @since 1.0
	 */
	@Override
	protected synchronized void onIOException(IOException e) {
		//e.printStackTrace();
		
		try {
			this.disconnect();
		} catch (IOException e1) {
			//e1.printStackTrace();
		}
		
		this.connect();		
	}
	
	public void setOnSig(OnSigStrengthRecv onSigStrengthRecv) {
		this.onSig = onSigStrengthRecv;
	}

	@Override
	protected void onSignalStrength(double strength) {
		if (this.onSig !=null) this.onSig.onSignalStrength(strength);
	}
	
	/**
	 * DOES NOTHING AS THIS IS NEVER CALLED ON THE ROBOT
	 * @since 1.0
	 */
	@Override
	protected void onSignalStrengthReq() {
		//Do nothing for I request not respond
	}

	@Override
	protected void onDeathMessage() {
		//Do nothing as I am the death sender		
	}
	
	public synchronized void disconnect() throws IOException {
		LCD.drawString("Disonnected", 0, 2);
		
		this.connected = false;
			try {
			if (this.os != null) {
				try {
					this.os.flush();
				} catch(IOException e) {}
				this.os.close();
			}
			if (this.is != null) this.is.close();
		} catch(IOException e) {}
		if (this.socket != null) this.socket.close();
	}

	@Override
	protected void onCubeUpdate(byte[] data){
		cubeBehavior.newCubeData(data);
	}

}
