package spaghetti.netty;

public interface OnSigStrengthRecv {
	public void onSignalStrength(double strength);	
}