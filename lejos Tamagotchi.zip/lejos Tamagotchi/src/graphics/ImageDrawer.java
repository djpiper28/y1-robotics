package graphics;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;

import javax.imageio.ImageIO;

import lejos.hardware.BrickFinder;
import lejos.hardware.lcd.GraphicsLCD;
import lejos.hardware.lcd.Image;

/**
 * ImageDrawer is instantiated with the name of an image in the resources
 * folder. Its constructor then loads the image into memory. It can then be
 * drawn on to the LCD with the method provided. To save memory it is important
 * for images to be small, low color depth lossless PNGs that fit on the screen.
 * 
 * @author Danny
 * @version 1.1
 */

public final class ImageDrawer {

	private BufferedImage image;
	private final static int BLACK_PIXEL = 1, IMAGE_BLACK = 0xFFFFFF;

	/**
	 * @param String imageName This parameter is a string of the image name to be
	 *               drawn on to the LCD. It is the filename of a PNG in the
	 *               resourses/ folder.
	 * @since 1.0
	 */
	public ImageDrawer(String imageName) throws IOException {
		this(new BufferedInputStream(ImageDrawer.class.getClassLoader().getResourceAsStream(imageName)));
	}

	/**
	 * @param InputStream imageInputStream This inputstream is that of the image to
	 *                    be loaded, main use if for testing when the code is not in
	 *                    a jar
	 * @since 1.0
	 */
	public ImageDrawer(InputStream imageInputStream) throws IOException {
		this.image = ImageIO.read(imageInputStream);
	}
	
	/**
	 * Images are really strange in leJOS, so what I do is: Take the image that was sent to the class.
	 * Then it translated it into a string of 0s and 1s, it then puts those 0s and 1s into a byte array.
	 * And then if that wasn't enough spaghetti, we have to invert all the rows because leJOS devs decided to smoke
	 * a fat one before writing this class.
	 * @author John & Danny
	 * @since 1.1
	 * @param drawX - x coord of top left of image to draw
	 * @param drawY - y corrd of top left of image to draW
	 */	
	public void drawImage(int drawX, int drawY) {

		GraphicsLCD g = BrickFinder.getDefault().getGraphicsLCD();
        final int padding = 8 - (this.image.getWidth() % 8);
        final byte[] data = new byte[((this.image.getWidth() + padding) / 8) * this.image.getHeight()];
        
        for (int y = 0, i = 0, j = 0; y < this.image.getHeight(); y++) {
            for (int x = 0; x < this.image.getWidth(); x++) {
                if ((this.image.getRGB(x, y) & IMAGE_BLACK) == 0) 
                    data[i] |= BLACK_PIXEL  << (7 - j);
                
                j++;
                
                if (j >= 8) {
                    j = 0;
                    i++;
                }
            }
            if (j != 0) {
                 j = 0;
                 i++;
            }
        }

        final byte[] transformedData = new byte[data.length];
        
        for (int row = 0; row < this.image.getHeight(); row++) {
            int rowLength = (this.image.getWidth() + padding) / 8;;
            byte[] newRow = new byte[rowLength];
            for (int counter = 0; counter < rowLength; counter++) {
                newRow[counter] = data[row * rowLength + counter];
            }

            for (int i = 0; i < newRow.length; i++) {
                transformedData[row * rowLength + i] = newRow[rowLength - i - 1];
            }

        }
        
        Image image = new Image(this.image.getWidth() + padding, this.image.getHeight(), transformedData);
        g.drawImage(image, drawX - padding, drawY, 0);
        
	}

	/**
	 * @return (int) the width of the image
	 * @since 1.0
	 */
	public int getWidth() {
		return this.image.getWidth();
	}

	/**
	 * @return (int) the height of the image
	 * @since 1.0
	 */
	public int getHeight() {
		return this.image.getHeight();
	}

}
