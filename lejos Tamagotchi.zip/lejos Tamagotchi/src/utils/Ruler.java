/**
 * @author Antonio
 * A refinement of the EV3UltrasonicSensor that may prove useful. Class should be instantiated, since it returns integers for the Pilot class. 
 */
package utils;

import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3UltrasonicSensor;

public class Ruler extends EV3UltrasonicSensor {

	static float measurement[] = new float[1];

	public Ruler(Port ultrasonicPort) {
		super(ultrasonicPort);
	}

	/**
	 * @return returns the integer distance in millimetres for consistency with the Pilot class
	 */
	public int measurement() {
		enable();
		getDistanceMode().fetchSample(measurement, 0);
		disable();
		return DecRounder.roundToInt(measurement[0] * 1000f);
	}

	/**
	 * @return returns floating point distance in millimetres
	 */
	public float measurementf() {
		measurement();
		return measurement[0];
	}

}
