/**
 * @author James
 */

package utils;

import java.util.HashMap;

public class RubiksCubeInterface {
    private static HashMap<Integer, String> cubeMessageConvert = new HashMap<Integer, String>();
    private int rotationCode;
    private int movesToSolve;

    public RubiksCubeInterface(byte[] data){
        fillConversionHashmap();
        rotationCode = (int) data[1];
        movesToSolve = (int) data[2];
    }

    public int getMove(){ // gets the bot move from the rotation code
        // moves: none: 0, forward: 1, back: 2, left: 3, right: 4
        int moveCode;
        switch(rotationCode){
            case -1:
                moveCode = 0;
                break;
            case 0:
                moveCode = 1;
                break;
            case 1:
                moveCode = 2;
                break;
            case 2:
                moveCode = 1;
                break;
            case 3:
                moveCode = 2;
                break;
            case 4:
                moveCode = 1;
                break;
            case 5:
                moveCode = 2;
                break;
            case 6:
                moveCode = 3;
                break;
            case 7:
                moveCode = 4;
                break;
            case 8:
                moveCode = 1;
                break;
            case 9:
                moveCode = 2;
                break;
            case 10:
                moveCode = 0;
                break;
            case 11:
                moveCode = 0;
                break;
            default:
                throw new IllegalStateException("Invalid move");

        }
        return moveCode;
    }

    public String getRotation(){
        return cubeMessageConvert.get((int) rotationCode);
    }

    public int getMovesToSolve(){
        return movesToSolve;
    }
    
    public int getRotationCode(){
        return rotationCode;
    }

    private void fillConversionHashmap(){
        cubeMessageConvert.put(-1, "N");
        cubeMessageConvert.put(0, "R");
        cubeMessageConvert.put(1, "'R");
        cubeMessageConvert.put(2, "L");
        cubeMessageConvert.put(3, "'L");
        cubeMessageConvert.put(4, "F");
        cubeMessageConvert.put(5, "'F");
        cubeMessageConvert.put(6, "U");
        cubeMessageConvert.put(7, "'U");
        cubeMessageConvert.put(8, "B");
        cubeMessageConvert.put(9, "'B");
        cubeMessageConvert.put(10, "D");
        cubeMessageConvert.put(11, "'D");
    }
}
