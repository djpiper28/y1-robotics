package utils;
import lejos.hardware.motor.BaseRegulatedMotor;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;
import lejos.robotics.chassis.Chassis;
import lejos.robotics.chassis.Wheel;
import lejos.robotics.chassis.WheeledChassis;
import lejos.robotics.localization.OdometryPoseProvider;
import lejos.robotics.localization.PoseProvider;
import lejos.robotics.navigation.MovePilot;

public class Pilot {

	final static float WHEEL_DIAMETER = 51; // The diameter (mm) of the wheels
	final static float AXLE_LENGTH = 44; // The distance (mm) your two driven wheels
	final static float ANGULAR_SPEED = 100; // How fast around corners (degrees/sec)
	final static float LINEAR_SPEED = 70; // How fast in a straight line (mm/sec)
	
	private BaseRegulatedMotor mL;
	private BaseRegulatedMotor mR;
	
	private Wheel wLeft;
	private Wheel wRight;
	
	private Chassis chassis;
	private MovePilot pilot;
	private PoseProvider poseProvider;
	
	public Pilot() {
		
		this.mL = new EV3LargeRegulatedMotor(MotorPort.A);
		this.wLeft = WheeledChassis.modelWheel(mL, WHEEL_DIAMETER).offset(-AXLE_LENGTH / 2);
		
		this.mR = new EV3LargeRegulatedMotor(MotorPort.B);
		this.wRight = WheeledChassis.modelWheel(mR, WHEEL_DIAMETER).offset(AXLE_LENGTH / 2);
		
		this.chassis = new WheeledChassis((new Wheel[] {wRight, wLeft}), WheeledChassis.TYPE_DIFFERENTIAL);
		this.pilot = new MovePilot(chassis);
		this.poseProvider = new OdometryPoseProvider(pilot);
		
		this.pilot.setLinearSpeed(Float.MAX_VALUE);
		this.pilot.setAngularSpeed(Float.MAX_VALUE);
		
	}
	
	public PoseProvider getPoseProvider() {
		return poseProvider;
	}
	
	public void move(int milli) {
		this.pilot.travel(milli);
	}
	
	public MovePilot getPilot() {
		return this.pilot;
	}
	
	public void stop() {
		this.pilot.stop();
	}
	
	public void rotate(int degrees) {
		this.pilot.rotate(degrees);
	}
	
	public void setLinearSpeed(float speed) {
		this.pilot.setLinearSpeed(speed);
	}
	
	public void setAngularSpeed(float speed) {
		this.pilot.setAngularSpeed(speed);
	}
	
	public boolean isMoving() {
		return this.pilot.isMoving();
	}
	
}
