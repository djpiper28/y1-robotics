package utils;
import lejos.hardware.Button;
import lejos.hardware.lcd.LCD;
import lejos.robotics.SampleProvider;
import lejos.utility.Delay;

/**
 * This class allows the robot holder to easily calibrate a sensor, using sample levels provided by a SampleProvider.
 * It has on-screen instructions.
 * @author Antonio
 */
public class Calibrator {
	private SampleProvider sampler;
	private float maxLevel, minLevel, avgLevel;
	
	public Calibrator(SampleProvider sampler) {
		this.sampler = sampler;
	}
	
	/**
	 * This method allows the robot-holder to continuously sample data of their choice overtime.
	 * Sampling starts and ends at ENTER button presses.
	 * Max/min/avg results are then displayed on the screen.
	 * At the end, press ENTER to exit the method (instruction not shown on-screen).
	 * @param action = verb to be displayed on the LCD during sampling
	 * @return the average level measured as a floating point number
	 */
	public float calibrate(String action) {
		maxLevel = 1000000;
	    minLevel = -1000000;
		float level[] = new float[1];
		LCD.drawString("Press ENTER to start " + action + "...", 0, 0);
		Button.ENTER.waitForPressAndRelease();
		Button.discardEvents();
		LCD.clear();
		LCD.drawString("Press ENTER to stop " + action + "...", 0, 0);
		while (Button.ENTER.isUp()) {
			sampler.fetchSample(level, 0);
			if (level[0] > maxLevel) {
				maxLevel = level[0];	
			}
			if (level[0] < minLevel) {
				minLevel = level[0];	
			}
		}
		avgLevel = (maxLevel+minLevel)/2;
		LCD.clear();
		LCD.drawString("Max: " + String.valueOf(maxLevel), 0, 0);
		LCD.drawString("Min: " + String.valueOf(minLevel), 0, 1);
		LCD.drawString("Avg: " + String.valueOf(avgLevel), 0, 2);
		Delay.msDelay(500); //Waits a half-second to avoid a double-press
		Button.discardEvents(); //Robustness [second layer of anti-double-press]
		Button.ENTER.waitForPressAndRelease();
		LCD.clear();
		return avgLevel;
	}
	
	/**
	 * This method allows the robot-holder to continuously sample data of their choice overtime.
	 * The local field avgLevel is updated to the returned average level sampled.
	 * Sampling starts and ends at ENTER button presses. The word "sampling" is shown on screen.
	 * Max/min/avg results are then displayed on the screen
	 * At the end, press ENTER to exit the method (instruction not shown on-screen).
	 * @return the average level measured as a floating point number
	 */
	public float calibrate() { return calibrate("sampling"); }
	
	/**
	 * This method returns the average of a specified number of calibrate methods' averages.
	 * The local field avgLevel is updated to this returned value.
	 * At the end, press ENTER to exit the method (instruction not shown on-screen).
	 * @param action = verb displayed on LCD when sampling
	 * @param times = number of times calibrate(String action) is called
	 * @return the average of the repeated calibration
	 */
	public float calibrate(String action, int times) {
		float accumu = 0;
		for (int i = 0; i < times; i++) {
			calibrate();
			accumu += getAvg();
		}
		avgLevel = accumu/times;
		LCD.drawString("Tot. Avg: " + String.valueOf(avgLevel),0,0);
		Button.ENTER.waitForPressAndRelease();
		LCD.clear();
		return avgLevel;
	}
	
	/**
	 * This method returns the average of a specified number of calibrate methods' averages.
	 * The local field avgLevel is updated to this returned value.
	 * Will calibrate specifically with the action verb set to "sampling."
	 * At the end, press ENTER to exit the method (instruction not shown on-screen).
	 * @param times = number of times calibrate(String action) is called
	 * @return the average of the repeated calibration
	 */
	public float calibrate(int times) {
		return calibrate("sampling", times);
	}
	
	public float getMax() { return maxLevel; }
	public float getMin() { return minLevel; }
	public float getAvg() { return avgLevel; }
	
}
