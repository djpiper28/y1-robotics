/**
 * 
 */
package utils;

/**
 * Negative determinant exception
 * @author danny
 * @version 1.0
 */
public class NegativeDeterminantException extends Exception {

	/**
	 * 
	 */
	public NegativeDeterminantException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public NegativeDeterminantException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public NegativeDeterminantException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public NegativeDeterminantException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public NegativeDeterminantException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
