package utils;
/**
 *  @author Antonio
 *	This <b>static</b> class is used to play music notes, beeps/buzzes and .WAV samples through the local speaker. 
 *	The default instrument is a piano for the notes, but a flute and xylophone are available options too.
 *	A lot of less relevant functions of the lejos.hardware.Sound class have been abstracted.
 *  However, this class has the key (ha) functionality of translating notes from programmer-defined Strings to a frequency, and taking fractions as arguments for note values. <br />
 *	The default tempo is 80 BPM. 
 *  C4 is middle C. A4 = 440Hz (concert tuning or whatever). <br />
 *  Call loadSettings() before use (once) of this class.
 *  Note: Methods that make sounds without the the word 'play' as a prefix all are playing system sounds. <br />
 *  <b>Important: there are no case sensitive methods in this class. The local audio device has a playable frequency range of 250Hz - 10,000Hz (C4 to D#9).</b>
 */

import lejos.hardware.Sound;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Random;

public class Speakers  {

static float tempo = 80;
static float timeRemaining = 0;
static int[] instrument = Sound.PIANO;
static boolean loaded = false;
static boolean fileHasTones = false;
static String lastSample = "";

enum INSTRUMENTS {
	PIANO(Sound.PIANO), FLUTE(Sound.FLUTE), XYLOPHONE(Sound.XYLOPHONE);

	private int[] envelope; 
	INSTRUMENTS(int[] envelope) {
		this.envelope = envelope;
	}
}

enum NOTE_NAMES {
	C(16.35f), DB(17.32f), D(18.35f), EB(19.45f), E(20.60f), F(21.83f), 
	GB(23.12f), G(24.50f), AB(25.96f), A(27.50f), BB(29.14f), B(30.87f);
	private float frequency;
	private NOTE_NAMES(float frequency) {
		this.frequency = frequency;
	}
}

/**
 * Loads relevant system settings and sets master volume at 50%. Call once only before using other methods.
 */
public static void loadSettings() {
	if (!loaded) {
		loaded = true;
		Sound.loadSettings();
		Sound.setVolume(50);
	}
}

/**
 * Set the internal tempo of the Speakers class.
 * Note: only change this if your desired time signature is not x/4 where x is any positive integer
 * @param bpm the tempo in beats per minute
 */
public static void setTempo(float bpm) { tempo = bpm; }

/**
 * Set the master volume of the audio device
 * @param masterVol volume (0 - 100)
 */
public static void setVolume(int masterVol) { 
	Sound.setVolume(ensurePercentage(masterVol));
}

/* zero to a hundred */
private static int ensurePercentage(int num) {
	if (num < 0) { 
		return 0;
	}	else if (num > 100) {
		return 100;
	} else {
		return num;
	}
}

/**
 * Get the master volume of the audio device
 * @return integer
 */
public static int getVolume() { 
	return Sound.getVolume();
}

/**
 * Set the instrument of the audio device to either Piano, Flute or Xylophone. This affects the playNote/playNotes functions.
 * @param instString, the string name of the instrument
 */
public static void setInstrument(String instString) {
	instrument = INSTRUMENTS.valueOf(instString.toUpperCase()).envelope;
}

/**
 * Beep. This method plays a beep sound.
 */
public static void beep() { Sound.beep(); }

/**
 * Beep for a specified number of times. Runs the Sound.twoBeep() method if 2 times are specified.
 * @param times number of times to beep
 */
public static void beep(int times) {
	if (times == 2) {
		Sound.twoBeeps();
		return;
	}
	for (int i=0; i < times; i++) { 
		Sound.beep();
		}
}

/**
 * Buzz. This method plays a buzz sound.
 */
public static void buzz() { Sound.buzz(); }

/**
 * Buzz for a specified number of times.
 * @param times number of times to buzz
 */
public static void buzz(int times) { for (int i=0; i < times; i++) { Sound.buzz(); } }

/**
 * Beeps in an ascending arpeggio
 */
public static void ascArp() { Sound.beepSequenceUp(); }  

/**
 * Beeps in an descending arpeggio
 */
public static void descArp() { Sound.beepSequence(); }  

/**
 * @return returns the time remaining of the currently playing sound in milliseconds (ms).
 */
public static int getTimeLeft() { return Sound.getTime(); }

/**
 * @return the time remaining of the currently playing sound as a String in minutes:seconds format (e.g. 10:05).
 * The zero padding ensures that there will always be a minimum of 2 digits before and after the colon.
 */
public static String getMinSec() {
	int minutes = 1000 * getTimeLeft()/60;
	int seconds = (1000 * getTimeLeft()) % 60;
	return String.format("%02d", minutes) + ":" + String.format("%02d", seconds);
}

/**
 * @return the name of the musical artist from the last played track 
 * Assumes the source filename is of the format: {artist} - {track}.wav (e.g. Kurt Travis - Desperate.wav)
 */
public static String getArtist() {
	return lastSample.replaceAll("(\\s+-\\s+).*", "");
}

/**
 * @return the track name of the last played audio sample
 * Assumes the source filename is of the format: {artist} - {track}.wav (e.g. Eternity Forever - Movies.wav)
 */
public static String getTrack() {
	String noArtistName = lastSample.replaceAll(".*(\\s+-\\s+)", "");
	int dotIndex = noArtistName.lastIndexOf(".");
	if (dotIndex < 0) { return noArtistName; }
	return noArtistName.substring(0, dotIndex);
}

/**
 * @return the filename of the last played .wav sample or file passed into {@link #playSheet(String)}
 */
public static String getFileName() {
	return lastSample;
}

/**
 * 
 * @param filename the name of the audio file (must be MONO, between 8kHz-48kHz sampling rate, and either 8 or 16 bit depth) 
 * @return the sample length in milliseconds, or -1 if there is an error
 */
public static int playSample(String filename) {
	File file = null;
	try {
		file = new File(filename);
	} catch (NullPointerException e) {
		System.err.println("Audio file not found.");
		return -1;
	}
	updateLastSample(filename);
	return Sound.playSample(file);
}

/**
 * @param filename the name and extension of the audio file (must be MONO, between 8kHz-48kHz sampling rate, and either 8 or 16 bit depth) 
 * @param vol the <b>relative</b> volume as a percentage of the master volume (0-100)
 * @return the sample length in milliseconds, or -1 if there is an error
 */
public static int playSample(String filename, int vol) {
	File file = null;
	try {
		file = new File(filename);
	} catch (NullPointerException e) {
		System.err.println("Audio file not found.");
		return -1;
	}
	updateLastSample(filename);
	return Sound.playSample(file, ensurePercentage(vol));
}

/**
 * This method allows you to send musical notes to the robot to queue and play from a text file.
 * The format of the file is below, line by line (no curly braces necessary): <br />
 * [optional] TEMPO {bpm (float)} <br />
 * [optional] TONES               <br />
 * {required} SHEET               <br />
 * {composition below}            <br />
 * Tag functionality:             <br />
 * TEMPO {bpm} specifies the tempo the robot will be set to (cannot be fractal). The bpm must be on the same line as TEMPO. e.g. TEMPO 69 															<br />
 * TONES will play the musical notes as tones instead of notes (the default), and you can specify them as tones instead.														<br />
 * SHEET marks the end of the optional tags and the start (exclusive) of all the notes to be queued and played. 																<br />
 * Rules for the file formatting:	<br />
 * The file tags are TEMPO, RESTS, TONES AND SHEET. <br />
 * The TEMPO tag must have its BPM number present in the same line. (It will be parsed to a float.) <br />
 * The TEMPO and TONES tags can appear in either order, and even on the same line. <br />
 * SHEET, however, has to be in any line that is below the final optional tag. <br />
 * The tags are not case sensitive. <br />
 * After the SHEET tag, in the lines below, the notes/tones are specified. <br />
 * The aforementioned notes/tones may be specified with each note/tone separated by any type (or combination) of whitespace.
 * It's recommended to separate notes by tabs and line-breaks, but it's up to you. The note will still be registered. <br />
 * Example <a href="https://https://imgur.com/a/lDECIns">here</a> 
 * @see #playNote(String) see how to format <i>notes.</i>	
 * @see #playTone(String) see how to format <i>tones.</i>
 * @param filename the directory (if not the same as this class), name and extension of the text file to parse and play
 */
public static void playSheet(String filename) {
	String[] notesToPlay = parseSheet(filename);
	if (notesToPlay[0].equals("-1")) {
		fileHasTones = false;
		return; //error in parseSheet();
	}
	if (fileHasTones) {
		playTones(notesToPlay);
	} else {
		playNotes(notesToPlay);
	}
}

/**
 * Plays a random system sound.
 */
public static void RandomSound() {
	Random rand = new Random();
	Sound.systemSound(false, rand.nextInt(5));
}

/**
 * Makes random system sounds for a specified number of times.
 * @param times number of times to randomise and play a sound
 */
public static void RandomSounds(int times) {
	for (int i = 0; i < times; i++) {
		RandomSound();
	}
}

/**
 * Causes the local audio device to play a musical note. The note models the ADSR envelope of the set class instrument.
 * This method is non-blocking. Each note is queued and plays for its full value.
 * The difference between notes and tones in the context of the Speakers class is that notes model the ADSR envelope of the set class instrument, 
 * and are stuck at a relative volume of 100% of the master volume.
 * Tones however, do not model the ADSR envelope of the set instrument, but can each have individual relative volumes to the master. <br />
 * See below on how to specify <i>notes:</i> <br />
 * Required = {}, optional = [], grouping = () <br />
 * { ({letter}[sharp|flat]{octave})|"REST" }{:}{note value} <br />
 * Note values can be fractions, like 1/4 for a crotchet (quarter note), and also decimals. The length of time notes play for is based on the set class tempo. <br />
 * Examples: A#5:1/4 plays a# at octave 5 for a quarter note .... bb3:1 plays B-flat at octave 3 for whole note
 * <b>Note</b> (ha): omitting the required colon and note value will not result in an error, instead the note value will default to 1 (a whole note).
 * @param noteToPlay the note name and its value to play <b>(must be between C4 and D#9)</b>
 * @return the note value, or -1 if the call results in an error
 */
public static int playNote(String noteToPlay) {
	noteToPlay = noteToPlay.replaceAll("\\s",""); //remove whitespace
	String note = noteToPlay.replaceAll(":.*", "");
	if (note.equals(noteToPlay)) { return errWrongNoteFormat(noteToPlay); }
	String valueString = noteToPlay.replaceAll(".*:", "").replaceAll("\\=.*","");
	float parsedValue = makeFloat(valueString);
	if (noteToPlay.toUpperCase().contains("REST")) {
		if (parsedValue >= 0) {
			playTone("C4:" + parsedValue + "=0");
			return DecRounder.roundToInt(parsedValue);
		} else {
			return errWrongNoteFormat("REST");
		}
	}
	float value = 1;
	if (valueString.equals(noteToPlay)) { 
		value = 1;
	} else {
		value = parsedValue;
	}
	int noteLength = DecRounder.roundToInt(1000f * (60f / tempo) * value);
	Sound.playNote(instrument, getFrequency(note), noteLength);
	return noteLength;
}

/**
 * Plays a series of musical notes. The notes model the ADSR envelope of the set instrument to try and sound similar to said instrument.
 * Notes are queued in the robot memory and played from there, allowing this method to be non-blocking.
 * @param notesToPlay the String array of music notes and their values, in the Speakers class format. Formatting info: {@link #playNote(String)}
 */
public static void playNotes(String[] notesToPlay) {
	for (int i = 0; i < notesToPlay.length; i++) {
		playNote(notesToPlay[i]);
	}
}

/**
 * Causes the local audio device to play a musical note as a "tone".
 * This method is non-blocking. Each note is queued and plays for its full value.
 * The difference between notes and tones in the context of the Speakers class is that notes model the ADSR envelope of the set class instrument, 
 * and are permanently set at a relative volume of 100% of the master volume.
 * Tones however, do not model the ADSR envelope of the set instrument, but can each have individual relative volumes to the master. <br />
 * See below on how to specify <i>tones:</i> <br />
 * Required = {} ... optional = [] <br />
 * { {letter}[sharp|flat]{octave}["="relativeVol] | "REST" }{:}{note value} <br />
 * Note values can be fractions, like 1/2 for a minim (half note), and also decimals. The length of time tones play for is based on the set class tempo. <br />
 * Example: C#3:1/4=70 plays c# at octave 3 for a half note at 70% of the master volume. <br />
 * <b>Note</b> (ha): omitting the required colon and note value will not result in an error, instead the note value will default to 1 (a whole note). 
 * If no relative volume (relativeVol) is specified, the tone will play at 100% of master volume.
 * @param toneToPlay the note name and its value to play <b>(must be between C4 and D#9)</b>
 * @return the tone value, or -1 if the call results in an error
 */
public static int playTone(String toneToPlay) {
	toneToPlay = toneToPlay.replaceAll("\\s","");
	String note = toneToPlay.replaceAll(":.*", "");
	if (note.equals(toneToPlay)) { return errWrongToneFormat(toneToPlay); }
	String valueString = toneToPlay.replaceAll(".*:", "").replaceAll("\\=.*","");
	float parsedValue = makeFloat(valueString);
	if (toneToPlay.toUpperCase().contains("REST")) {
		if (parsedValue >= 0) {
			playTone("C4:" + parsedValue + "=0");
			return DecRounder.roundToInt(parsedValue);
		} else {
			return errWrongToneFormat("REST");
		}
	}
	float value = 1;
	int relativeVol = 100;
	if (valueString.equals(toneToPlay)) { 
		value = 1;
	} else {
		value = parsedValue;
	}
	String volString = toneToPlay.replaceAll(".*\\=", "");
	try {
		relativeVol = Integer.parseInt(volString);
	} catch (NumberFormatException e) {
		if (!volString.trim().equals("") && volString.contains("=")) { 
			System.err.println("Error retrieving volume from String: " + "\"" + toneToPlay + "\"");
		}
	}
	int toneLength = DecRounder.roundToInt(1000f * (60f / tempo) * value);
	Sound.playTone(getFrequency(note), toneLength, relativeVol);
	return toneLength;
}

/**
 * Plays a series of tones. How Speakers tones sound are independent of the set instrument (unlike Speakers class notes).
 * Tones are queued in the robot memory and played from there, allowing this method to be non-blocking.
 * @see #playTone(String) Info on <i>tones</i> and their formatting.
 * @param tonesToPlay a String array of musical notes to be played as Speakers-class tones 
 */
public static void playTones(String[] tonesToPlay) {
	for (int i = 0; i < tonesToPlay.length; i++) {
		playTone(tonesToPlay[i]);
	}
}

/**
 * Private method to translate a musical note String to its integer frequency.
 * @param noteTone the note or tone passed from a local method.
 * @return the frequency of the note as a rounded integer. Returns -1 if there is an error. Forces return value within 250Hz-10KHz range.
 */
private static int getFrequency(String noteTone) {
	String noteToneName = noteTone.replaceAll("\\d|\\s|:.*", "").toUpperCase();
	if (noteToneName.equals("") | noteToneName == noteTone) {
		System.err.println("Error parsing note: " +"\"" + noteToneName + "\""  + "in method getFrequency(String).");
		return -1;
	}
	int octave = Integer.parseInt(noteTone.replaceAll("[^\\d]|\\s", ""));
	if (noteToneName.length() > 1 && noteToneName.charAt(1) == '#') {
	//Converts sharps to flats for the enum
		if (noteToneName.contains("B#")) {
			noteToneName = "C";
			octave++;
		} else {
				char noteToneLetter = (char) (noteToneName.charAt(0) + 1); //A -> B -> C etc...
				noteToneName = noteToneLetter + "B"; //B means 'flat' here
		}
	}
	if (noteToneName.contains("FB")) { noteToneName = "E"; }
    if (noteToneName.contains("CB")) {
		noteToneName = "B";
		octave--;
	}
	int freq = DecRounder.roundToInt(NOTE_NAMES.valueOf(noteToneName).frequency * (1 << octave)); //Bit-Shifting to get powers of 2
	if (freq > 10000 || freq < 250) {
		if (freq > 10000) { freq = 9956; }
		if (freq < 250) { freq = 262; } 
		System.err.println("Note must be between 250 and 10000 Hz (C4 to D#9). Nearest music note frequency returned.");	
	}
		return freq;
}

/* Any float you can parse I can parse better; I can parse any float better than you */
/* We all FLOAT down here */
private static float makeFloat(String expression) {
	float value = -1.0f;
	try {
		if (expression.contains("/")) {
			value = Float.parseFloat(expression.replaceAll("/.*", "")) / Float.parseFloat(expression.replaceAll(".*/", ""));
		} else {
			value = Float.parseFloat(expression.replaceAll("[^\\d.]",""));
		}
	} catch (NumberFormatException e) {
		System.err.println("String expression \"" + expression + "\" was unable to be parsed to a floating-point number.");
	}
	return value;
}

/* parses 'sheet' music info from a text file to a String array, for the playSheet(String) method */
private static String[] parseSheet(String filename) {
	fileHasTones = false;
	LinkedList<String> sheetList = new LinkedList<String>(); 
	File file = new File(filename);
	String line = "";
	BufferedReader reader = null;
	try {
		reader = new BufferedReader(new FileReader(file));
	} catch (FileNotFoundException e) {
		System.err.println("File not found.");
		return new String[] {"-1"};
	}
	try {
		while (!line.contains("SHEET")) {
			line = reader.readLine();
			if (line == null) { break; }
			if (line.equals(line.replaceAll("[a-zA-Z0-9]", ""))) { continue; }
			line = line.toUpperCase();
			if (line.contains("TEMPO")) {
				float floatyLine = makeFloat(line);
				if (floatyLine >= 0) {
					setTempo(floatyLine);
				} else {
					System.err.println("Must specify bpm in the same line as the TEMPO tag.");
				}
			}
			if (line.contains("TONES")) {
				fileHasTones = true;
			}
		}
		while (line != null) {
			line = reader.readLine();
			if (line == null) { break; }
			if (line.equals(line.replaceAll("\\w", ""))) { continue; }
			String[] notesToPlay = line.split("\\s"); //makes sure that elements separated by one or more whitespace are split
			for (String s : notesToPlay) {
				if (!s.equals("")) {
					sheetList.add(s.trim());
				}
			}
		}
		reader.close();
		updateLastSample(filename);
	} catch (IOException e) {
		System.err.println("Error reading from file: " + filename);
		e.printStackTrace();
		sheetList = new LinkedList<String>();
		sheetList.add("-1");
	}
	return sheetList.toArray(new String[0]); //JVM optimisation
}

/**
 * Updates the lastSample field with the last played sample's filename, with any path prefix removed.
 * @param filename filename of sample with relative path.
 */
private static void updateLastSample(String filename) {
	int bslashIndex = 0;
	if (filename.lastIndexOf('\\') != -1) { bslashIndex = filename.lastIndexOf('\\') + 1; }
	lastSample = filename.substring(bslashIndex);
}

/* Error message for poor tone formatting */
private static int errWrongToneFormat(String e) {
	System.err.println(
			"Tone formatting error at String: \"" + e + "\"\n" 
			+ "String must take this form: \n"
			+ "(where required elements = {}, optional elements = [], grouping = ()): \n"
			+ "{ ({letter}[sharp|flat][\"=\"relativeVol]) | \"REST\" }{octave}{:}{note value} e.g. d#5:1/8"
			);
	return -1;
}

/* Error message for poor note formatting */
private static int errWrongNoteFormat(String e) {
	System.err.println(
			"Note formatting error at String: \"" + e + "\"\n"
			+ "String must take this form: \n"
			+ "(where required elements = {}, optional elements = [], grouping = ()): \n"
			+ "{ ({letter}[sharp|flat]{octave}) | \"REST\" }{:}{note value} e.g. REST:1/8"
			);
	return -1;
}

}
