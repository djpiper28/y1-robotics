

/**
 * @author Antonio
 * This is a static class which rounds floats and doubles to programmer-specified decimal places, using wrapper classes, primitives and arrays.
 * Its most powerful use is to both round <b>and</b> convert float/double types to int - all within a single method call by the programmer.
 * This class has a precision of 6-d.p. (roughly in line with floating-point accuracy) [note: more precise decimals can still be used just fine]
 */

package utils;
import java.text.DecimalFormat;

public class DecRounder {
	//Position of the decimal point
	static int dotPos;
	final static String decFormat = "#.######"; //6.d.p. precision.
	/**
	 * For rounding to a certain number of decimal places
	 * @param f floating-point number
	 * @param decPlaces decimal places
	 * @return returns rounded float (or -1.0 if there is an error)
	 */
	public static float round(float f, int decPlaces) {
		DecimalFormat df = new DecimalFormat(decFormat);
		String num =  df.format(f);
		return Float.parseFloat(roundAny(num, decPlaces));
	}
	
	/**
	 * For rounding to a certain number of decimal places
	 * @param d double point number
	 * @param decPlaces decimal places
	 * @return returns rounded double (or -1.0 if there is an error)
	 */
	public static double round(double d, int decPlaces) {
		DecimalFormat df = new DecimalFormat(decFormat);
		String num =  df.format(d);
		return Double.parseDouble(roundAny(num, decPlaces));
	}

	
	/**
	 * This is tied with its float-point brother as the most powerful method in the class
	 * Both methods return a rounded up/down integer, parsed from a float or double
	 * @param double type to process
	 * @return returns primitive int (or -1 if there is an error)
	 */
    public static int roundToInt(double d) {
		DecimalFormat df = new DecimalFormat(decFormat);
		String num =  df.format(d);
		return Integer.parseInt(roundAny(num, 0));
	}

    /**
	 * This method is tied with its double brother as the most useful method in the class
	 * Both methods return a rounded up/down integer, parsed from a float or double
	 * @param float-point type to process
	 * @return returns int (or -1 if there is an error)
	 */
    public static int roundToInt(float f) {
		DecimalFormat df = new DecimalFormat(decFormat);
		String num =  df.format(f);
		return Integer.parseInt(roundAny(num, 0));
	}
	
    /**
     * The general application of this class's function.
     * @param num the String argument passed to the function from the DecRounder class
     * @param decPlaces decimal places
     * @return returns String so that each class method can return appropriate types after parsing
     */
	private static String roundAny(String num, int decPlaces) {
		boolean isNegative = false;
		String infinity = "\u221e";
		if (num.equals(infinity) || num.equals("-" + infinity)) {
			//System.err.println("You're seriously dividing by zero? Buddy, get it together...");
			return "-1";
		}
		if (num.replace(".", "").length() + 2 <= num.length()) {
			System.err.println("Error: multiple decimal points detected.");
			return "-1";
		}
		if (decPlaces < 0) {
			System.err.println("Error: 'decPlaces' must be a positive integer.");
			return "-1";
		}
		if (num.startsWith("-")) {
			isNegative = true;
			num = num.substring(1);
		}
		dotPos = num.lastIndexOf(".");
		//deletes any floating point 'f' chars that might be there
		num.replace("f", "");
		//if no decimal point is found, returns the number as a float
		if (dotPos == -1) { return num; }
		try {
			String concat = "";
			int leftDigit, rightDigit;
            int opUpperBound = dotPos + decPlaces + 1;
			char[] splitNum = num.toCharArray();
            int rpos = opUpperBound;
			int lpos = opUpperBound - 1;
			if (rpos >= num.length()) { return num; }
			if (lpos == dotPos) { lpos--; }
            leftDigit = Integer.parseInt(String.valueOf(splitNum[lpos])); 
            rightDigit = Integer.parseInt(String.valueOf(splitNum[rpos]));
                if (rightDigit >= 5) {
                    leftDigit++;
					if (leftDigit > 9) {
						splitNum[lpos] = 'x'; 
					} else {
						splitNum[lpos] = Character.forDigit(leftDigit, 10);
					}
                    for (int j = lpos - 1; j > -1; j--) {
						int k = j + 1;
						if (j == dotPos) { j--; }
						if (k == dotPos) { k--; }
							if (splitNum[k] == 'x') {
								splitNum[k] = '0';
								leftDigit = 1 + Integer.parseInt(String.valueOf(splitNum[j]));
								if (leftDigit > 9) {
									splitNum[j] = 'x';
								} else {
									splitNum[j] = Character.forDigit(leftDigit, 10);
								}
							}
                }    
            }
            if (opUpperBound == dotPos + 1) { opUpperBound--; }
			for (int cursor = 0; cursor < opUpperBound; cursor++) {
				concat += String.valueOf(splitNum[cursor]);
            }
			if (splitNum[0] == 'x') { concat = 10 + concat.substring(1); }
			if (isNegative) { concat = "-" + concat; }
			return concat;
		} catch (ArrayIndexOutOfBoundsException e) { 
			System.err.println("Error: invalid number (must not start or end with a decimal point).");
			return "-1"; 
		}
	}
}
