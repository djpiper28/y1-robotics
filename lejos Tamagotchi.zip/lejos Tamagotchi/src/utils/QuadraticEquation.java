/**
 * 
 */
package utils;

/**
 * Quadratic equation maths class
 * @author danny
 * @version 1.0
 */
public class QuadraticEquation {

	private double solutionA, solutionB;
	
	public double getSolutionA() {
		return solutionA;
	}

	public double getSolutionB() {
		return solutionB;
	}

	/**
	 * Calculates the roots of the quadratic in form ax^2 + bx + c = 0
	 * @param a x^2 coffecient
	 * @param b x coefficient
	 * @param c x^0 coefficient
	 * @throws NegativeDeterminantException if the determinant is less than 0 (no roots)
	 * @since 1.0
	 */
	public QuadraticEquation(double a, double b, double c) throws NegativeDeterminantException {
		double det = sqr(b) - 4 * a * c;
		
		if (det < 0) {
			throw new NegativeDeterminantException();
		}
		
		double sqrtDet = Math.sqrt(det);
		
		this.solutionA = (-b + sqrtDet) / 2 * a;
		this.solutionB = (-b - sqrtDet) / 2 * a;
	}
	
	public static double sqr(double a) {
		return a * a;
	}
	
}
