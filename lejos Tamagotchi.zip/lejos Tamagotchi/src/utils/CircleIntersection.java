/**
 * 
 */
package utils;

/**
 * Circle intersection maths class Ported from my C prototype so may not be the
 * best java implementation
 * 
 * @author danny
 * @version 1.0
 */
public class CircleIntersection {

	private Vect2D[] intersections;
	private static final double THRESHOLD = 0.001d; // Double precision errors + other errors

	/**
	 * @return the intersections of the two circles or the closest points
	 * @since 1.0
	 */
	public Vect2D[] getIntersections() {
		return intersections;
	}

	/**
	 * Gets the circle maths done
	 * 
	 * @param a -> vector of a centre where a.mag is the radius
	 * @param b -> vector of b centre where b.mag is the radius
	 * @since 1.0
	 */
	public CircleIntersection(Vect2D a, Vect2D b) {
		double centreDist = a.dist(b);

		a.setMag(Math.abs(a.getMag()));
		b.setMag(Math.abs(b.getMag()));
		double sumRadii = a.getMag() + b.getMag();

		// Case 0 - 2 intersections (the same as case 1, but case 1 can get away with
		// less maths so has less run time and is better for the ev3 as such)
		if (centreDist > THRESHOLD && Math.abs(a.getMag() - b.getMag()) < centreDist && centreDist < sumRadii) {
			case0(a, b, sumRadii, centreDist);
		}

		// Case 1 - 1 intersection
		else if (Math.abs(centreDist - sumRadii) < THRESHOLD) {
			case1(a, b, sumRadii);
		}

		// Case 2 they are in the same location
		else if (centreDist < THRESHOLD) {
			case2();
		}

		// Case 3 no intersections - get aprox using radii mid points
		else {
			case3(a, b);
		}
	}

	private double circleXUp(double y, double a, double b, double r) throws NegativeDeterminantException {
		return new QuadraticEquation(1, -2 * a, sqr(a) + sqr(y) - 2 * b * y + sqr(b) - sqr(r)).getSolutionA();
	}

	private double circleXLow(double y, double a, double b, double r) throws NegativeDeterminantException {
		return new QuadraticEquation(1, -2 * a, sqr(a) + sqr(y) - 2 * b * y + sqr(b) - sqr(r)).getSolutionB();
	}

	private void case0(Vect2D a, Vect2D b, double sumRadii, double centreDist) {
		double psi = sqr(b.getX()) + sqr(b.getY()) + sqr(a.getMag()) - sqr(b.getMag()) - sqr(a.getX()) - sqr(a.getY());
		double phi = 2 * a.getY() - 2 * b.getY();
		double omega = 2 * b.getX() - 2 * a.getX();

		// y^2 coeff
		double aa = 1 + sqr(phi / omega);
		// y^1 coeff
		double bb = 2 * (psi * phi) / sqr(omega) - 2 * a.getX() * (phi / omega) - 2 * a.getY();
		// y^0 coeff
		double cc = sqr(psi / omega) - 2 * a.getX() * (psi / omega) + sqr(a.getX()) + sqr(a.getY()) - sqr(a.getMag());

		// Check for real solutions
		// The solutions will be real as the first if ensures that the circles
		// match this case
		try {
			QuadraticEquation yEq = new QuadraticEquation(aa, bb, cc);

			double intYA = yEq.getSolutionA();
			double intYB = yEq.getSolutionB();

			// solve for x
			double xForA[] = new double[4];
			xForA[0] = circleXUp(intYA, a.getX(), a.getY(), a.getMag());
			xForA[1] = circleXLow(intYA, a.getX(), a.getY(), a.getMag());

			xForA[2] = circleXUp(intYB, a.getX(), a.getY(), a.getMag());
			xForA[3] = circleXLow(intYB, a.getX(), a.getY(), a.getMag());

			double xForB[] = new double[4];
			;
			xForB[0] = circleXUp(intYA, b.getX(), b.getY(), b.getMag());
			xForB[1] = circleXLow(intYA, b.getX(), b.getY(), b.getMag());

			xForB[3] = circleXUp(intYB, b.getX(), b.getY(), b.getMag());
			xForB[4] = circleXLow(intYB, b.getX(), b.getY(), b.getMag());

			int ptr = 0;

			this.intersections = new Vect2D[2];

			for (int i = 0; i < 2; i++) {
				for (int j = 0; j < 2; j++) {
					if (Math.abs(xForA[i] - xForB[j]) < THRESHOLD) {
						Vect2D vect = new Vect2D(xForA[i], intYA, 0);

						if (ptr < 2) {
							this.intersections[ptr] = vect;
							ptr++;
						}

					}
				}
			}

			for (int i = 2; i < 4; i++) {
				for (int j = 2; j < 4; j++) {
					if (Math.abs(xForA[i] - xForB[j]) < THRESHOLD) {
						Vect2D vect = new Vect2D(xForA[i], intYB, 0);

						if (ptr < 2) {
							this.intersections[ptr] = vect;
							ptr++;
						}
					}
				}
			}

			if (ptr == 1) {
				this.intersections = new Vect2D[] { this.intersections[0] };
			}

		} catch (NegativeDeterminantException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void case1(Vect2D a, Vect2D b, double sumRadii) {
		Vect2D vect = new Vect2D(a.getX() + ((b.getX() - a.getX()) * (a.getMag() / sumRadii)),
				a.getY() + ((b.getY() - a.getY()) * (a.getMag() / sumRadii)), 0);
		this.intersections = new Vect2D[] { vect };
	}

	private void case2() {
		this.intersections = new Vect2D[] { new Vect2D(0, 0, 0) };
	}

	private void case3(Vect2D a, Vect2D b) {
		Vect2D vect;
		if (a.getMag() < b.getMag()) {
			vect = a.clone();
		} else {
			vect = b.clone();
		}

		vect.incX(0.01);
		vect.incY(0.01);

		this.intersections = new Vect2D[] { vect };
	}

	public static double sqr(double a) {
		return a * a;
	}

}
