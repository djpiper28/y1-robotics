package utils;

/**
 * Vector maths class
 * @author danny
 * @version 1.0
 */
public class Vect2D {

	private double x, y, mag;
	
	/**
	 * Creates a vector
	 * @param x part of vect
	 * @param y part of vect
	 * @param mag - arbitary value that represents some property that you the user must decide
	 * @since 1.0
	 */
	public Vect2D(double x, double y, double mag) {
		this.x = x;
		this.y = y;
		this.mag = mag;
	}

	/** 
	 * gets x
	 * @return x of the vector
	 * @since 1.0
	 */
	public synchronized double getX() {
		return x;
	}

	/**
	 * sets x
	 * @param x of the vector
	 * @since 1.0
	 */
	public synchronized void setX(double x) {
		this.x = x;
	}

	/** 
	 * gets y
	 * @return y of the vector
	 * @since 1.0
	 */
	public synchronized double getY() {
		return y;
	}
	
	/**
	 * sets y
	 * @param y of the vector
	 * @since 1.0
	 */
	public synchronized void setY(double y) {
		this.y = y;
	}

	/**
	 * Gets the magnitude of the vector
	 * @see public Vect2D(double x, double y, double mag)
	 * @return the magnitude
	 * @since 1.0
	 */
	public synchronized double getMag() {
		return mag;
	}
	
	/**
	 * Sets the magnitude of the vector
	 * @see public Vect2D(double x, double y, double mag)
	 * param mag -> the magnitude
	 * @since 1.0
	 */
	public synchronized void setMag(double mag) {
		this.mag = mag;
	}
	
	/**
	 * Squares a number
	 * @param a -> num to square
	 * @return
	 * @since 1.0
	 */
	public static double sqr(double a) {
		return a * a;
	}
	
	/**
	 * Clones the object
	 * @since 1.0
	 */
	public Vect2D clone() {
		return new Vect2D(this.getX(), this.getY(), this.getMag());
	}
	
	/**
	 * Gets the length of the vector using pythagoras
	 * @return length of the vector
	 * @since 1.0
	 */
	public double getSize() {
		return Math.sqrt(sqr(this.getX()) + sqr(this.getY()));
	}
	
	/**
	 * Turns this vector into a unit vector
	 * @since 1.0
	 */
	public void normalise() {
		double size = this.getSize();
		this.setX(this.getX() / size);
		this.setY(this.getY() / size);
	}
	
	/**
	 * Gets the distance between two postion vectors
	 * @param otherVect -> another vector
	 * @return the distance between two position vectors
	 * @since 1.0
	 */
	public double dist (Vect2D otherVect) {
		return Math.sqrt(sqr(this.getX() - otherVect.getX()) 
				+ sqr (this.getY() - otherVect.getY()));
	}

	/**
	 * Incs x by
	 * @param x
	 * @since 1.0
	 */
	public synchronized void incX(double x) {
		this.setX(this.getX() + x);
	}
	
	/**
	 * Incs y by
	 * @param y
	 * @since 1.0
	 */
	public synchronized void incY(double y) {
		this.setY(this.getY() + y);
	}
	
}
