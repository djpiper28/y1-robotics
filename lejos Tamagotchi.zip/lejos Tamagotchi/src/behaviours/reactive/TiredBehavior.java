package behaviours.reactive;

import emotions.Emotions;
import lejos.hardware.lcd.LCD;
import lejos.robotics.subsumption.Behavior;
import utils.Speakers;

public class TiredBehavior implements Behavior {

	private static final float tiredThreshold = 0.2f;
	private Emotions emotions;
	
	public TiredBehavior(Emotions emotions) {
		this.emotions = emotions;
	}
	
	public static float getTiredThreshold() {
		return tiredThreshold;
	}
	
	@Override
	public void action() {
		LCD.clear();
		LCD.drawString("I am tired", 2, 2);		
	}

	@Override
	public void suppress() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean takeControl() {
		// TODO Auto-generated method stub
		return this.emotions.getTired() <= tiredThreshold;
	}

}
