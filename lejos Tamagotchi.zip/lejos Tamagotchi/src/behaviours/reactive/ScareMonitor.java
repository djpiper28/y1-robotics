package behaviours.reactive;
/**
 * @author Nio from the Matrix

 * This volume-monitoring runnable is designed to be instantiated and then placed in a thread
 * When there is a loud enough sound (as checked every CHECK_DELAY milliseconds) the fear of the Emotions object increases
 * v1.0
 * v1.1: calibrate() method contents have been generalised and put into a Calibrator class
 * v1.2: support for Emotions
 * v1.3: renamed arguments, made allowance for the Arbitrator object handling responses
 * v1.4: tidied up code to support newer packaging system; generalised params
 * v1.5: fixed constructor
 */

import emotions.Emotions;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.NXTSoundSensor;
import lejos.robotics.SampleProvider;
import lejos.utility.Delay;
import utils.Calibrator;


public class ScareMonitor implements Runnable {
	
	NXTSoundSensor soundSensor;
	Emotions emotions;
	Port soundPort;
	private float threshold = 1000; //abnormally high because threshold will be set at constructor
	private final static int STAGGER = 1000; //ms to wait after detecting a fright (msdelay)
	
	/** 
	 * @param emotions the emotions object for the Tamagotchi
	 * @param soundPort is passed SensorPort.SX, where X is the port number which the NXTSoundSensor is connected to
	 * @param threshold is the dbA volume which causes the Emotions object fear value to go up by 0.3
	 */
	public ScareMonitor(Emotions emotions, Port soundPort, float threshold) {
		this.emotions = emotions;
		this.soundPort = soundPort;
		soundSensor = new NXTSoundSensor(soundPort);
		this.threshold = threshold;
	}
	
	/**
	 * @Override
	 * Starts running -> listens to surroundings -> hears loudness at/or above endThreshold -> increases fear
	 */
	@Override
	public void run() {
		SampleProvider sampler = soundSensor.getDBAMode();
		float volume[] = new float[1];
		while (true) {
			sampler.fetchSample(volume, 0);
			if (volume[0] >= threshold) {
				emotions.updateFear(-0.1f); 
				Delay.msDelay(STAGGER);
			}
		}
	}
	
	/**
	 * This method allows the robot-holder to sample volume levels overtime between ENTER presses
	 * Max/min/avg results are then displayed on the screen
	 * The data can be used to generate a sensible endThreshold value
	 * Press ENTER once again to exit the method after results are shown
	 */
	public void calibrate() {
		SampleProvider sampler = soundSensor.getDBAMode();
		Calibrator calvin = new Calibrator(sampler);
		calvin.calibrate("listening");
	}
	
}
	

