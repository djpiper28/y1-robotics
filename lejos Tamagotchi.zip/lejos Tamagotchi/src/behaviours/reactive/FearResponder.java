/*
 * @author Anto-Nio from the Matrix
 * This Behaviour class is designed to be instantiated and used in an Arbitrator
 */
package behaviours.reactive;
import emotions.Emotions;
import lejos.robotics.subsumption.Behavior;
import utils.Pilot;
import utils.Ruler;
import utils.Speakers;

public class FearResponder implements Behavior {
	Emotions emotions;
	Pilot pilot;
	Ruler ruler;
	final static float fearThreshold = 0.4f;
	
	public FearResponder(Emotions emotions, Pilot pilot, Ruler ruler) {
		this.emotions = emotions;
		this.pilot = pilot;
		this.ruler = ruler;
	}
	
	/**
	 * @return the lowest bound (inclusive) of fear that must be reached to execute a response in the action() method
	 */
	public static float getThreshold() {
		return fearThreshold;
	}
	@Override
	/**
	 * When fear <= 0.25: turns around, gets distance to the nearest wall and moves that distance [doesn't face forward out of pure unadulterated terror]
	 * Else when fear is between <= 0.4: turns around and moves 10cm, then faces forward
	 * Else when fear is between <= 0.5: looks left, then right, then faces forward
	 * Fear is lowered by 0.5 each time the robot is frightened.
	 */
	public void action() {
		
		if (emotions.getFear() <= 0.25f) {
			pilot.rotate(180);
			//int goal = ruler.measurement(); Removed because it often is stuck because distance is infinite
			pilot.move(500);
			Speakers.playSample("yeet.wav");
			emotions.updateFear(0.1f);
			emotions.updateTired(-0.2f);
		} else if (emotions.getFear() <= 0.3f) {
			pilot.rotate(90);
			pilot.rotate(-180);
			pilot.rotate(90);
			Speakers.playSample("yeet.wav");
			emotions.updateFear(0.1f);
			emotions.updateTired(-0.2f);
		} else if (emotions.getFear() <= 0.4f) {
			pilot.rotate(180);
			pilot.move(100);
			emotions.updateFear(0.1f);
			emotions.updateTired(-0.2f);
		}
		
	}
	
	@Override
	public void suppress() {
		pilot.stop();
	}
	
	@Override
	public boolean takeControl() {
		return (this.emotions.getFear() <= fearThreshold);
	}
	
}
