package behaviours.reactive;

import emotions.Emotions;
import lejos.hardware.Button;
import lejos.hardware.lcd.LCD;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.robotics.SampleProvider;
import utils.Pilot;
import utils.Ruler;
import utils.Speakers;

/**
 * @author John
 * This class implements a runnable thread to check the distance in front of the robot.
 * If the user is close, then the robot will atempt to fist bump the user as a greeting.
 */
public class Wave implements Runnable {
	
	private Emotions emotions;
	private Ruler ruler;
	private Pilot pilot;
	
	private final static float closeThreshold = 0.2f;

	/**
	 * @param emotions -> Standard emotions object
	 * @param ruler -> Ruler object which has methods to measure distance using the ultrasonic sensor
	 * @param pilot -> Pilot class, controls the movement of the robot.
	 */
	public Wave(Emotions emotions, Ruler ruler, Pilot pilot) {
		this.emotions = emotions;
		this.ruler = ruler;
		this.pilot = pilot;
	}

	/**
	 * The robot is triggered if the user is within the
	 * distance threshhold and the robot is not too tired.
	 */
	@Override
	public void run() {
		while (true) {
			float measurement = ruler.measurementf();
			if (measurement < closeThreshold && emotions.getTired() > TiredBehavior.getTiredThreshold()) {
				this.pilot.move(utils.DecRounder.roundToInt(measurement * 1000));
				this.emotions.updateTired(-0.2f);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) { }
			}
		}
	}
	
}
