/**
 * 
 */
package behaviours.reactive;

import java.io.IOException;
import java.util.Random;

import common.netty.messages.SignalStrengthMessage;
import common.netty.messages.SignalStrengthReqMessage;
import emotions.Emotions;
import lejos.robotics.navigation.Pose;
import lejos.robotics.subsumption.Behavior;
import spaghetti.netty.RobotBtConnection;
import utils.CircleIntersection;
import utils.Pilot;
import utils.Vect2D;

/**
 * @author danny
 * @version 1.0
 */
public class ChaseBehavior implements Behavior {

	private Vect2D lastVect;
	private Vect2D[] positions;
	private int positionsPtr;
	private final static SignalStrengthMessage signalStrengthRequest
										 = new SignalStrengthMessage();
	private RobotBtConnection connection;
	private Pilot pilot;	
	private Emotions emotions;
	private Random random;
	private double sigStrength;
	private boolean isRead, hasCalled;
	private long lastCallback;
	private final static long TIMEOUT = 150;
	
	/**
	 * Ported from my C prototype so may introduce error
	 * @param currentPos -> current robot position
	 * @return new vector to travel in
	 * @since 1.0
	 */
	private Vect2D getNewVector(Vect2D currentPos) {
			//Get new direction vector        
		    if (positionsPtr == 0) {
		        Vect2D vectA = new Vect2D(random.nextInt(), random.nextInt(), 0);
		        return vectA;
		    } else if (positionsPtr == 1) {
		    	CircleIntersection ci = new CircleIntersection(positions[0], currentPos);
		    	Vect2D[] vects = ci.getIntersections();
		    	Vect2D vect = vects[0];
		        vect.incX(-currentPos.getX());
		        vect.incY(-currentPos.getY());
		        
		        return vect;
		    } else {
		        //Get intersections      
		    	CircleIntersection ci = new CircleIntersection(positions[1], currentPos);
		    	Vect2D[] vects01 = ci.getIntersections();
		    	
		    	
		    	ci = new CircleIntersection(positions[0], positions[1]);
		    	Vect2D[] vects12 = ci.getIntersections();
		        
		        //Get closest two points 
		        boolean changedFlag = false;
		        double minD = 0;
		        Vect2D vectA = new Vect2D(0, 0, 0);
		        Vect2D vectB = new Vect2D(0, 0, 0);
		        
		        for (int aCnt = 0; aCnt < vects01.length; aCnt++) {
		            for (int bCnt = 0; bCnt < vects12.length; bCnt++) {
		                double d = vects01[aCnt].dist(vects12[bCnt]);
		                if (d < minD || (!changedFlag)) {
		                    minD = d;
		                    changedFlag = true;
		                    
		                    vectA = vects01[aCnt];
		                    vectB = vects12[bCnt];
		                }            
		            }
		        }
		        	        
		        //Get midpoint
		        Vect2D vectC = new Vect2D((vectA.getX() + vectB.getX()) / 2, 
		                                  (vectA.getY() + vectB.getY()) / 2, 
		                                  0);
		        
		        //Get get vector of midpoint - robotPos      
		        vectC.incX(-currentPos.getX());
		        vectC.incY(-currentPos.getY());
		        
		        return vectC;
		    }
	}
	
	public ChaseBehavior(RobotBtConnection connection, Pilot pilot, Emotions emotions) {
		this.isRead = false;
		this.hasCalled = false;
		this.random = new Random();
		this.connection = connection;
		this.pilot = pilot;
		this.emotions = emotions;
		this.positions = new Vect2D[2];
	}
	
	/**
	 * @param signal signal strength read from socket
	 * @since 1.0
	 */
	public synchronized void setSignal(double signal) {
		this.sigStrength = 1 / (signal * signal);
		this.isRead = true;
		this.hasCalled = false;
	}

	@Override
	public void action() {
		if (!isRead) {			
			Pose p = pilot.getPoseProvider().getPose();
			Vect2D botLocation = new Vect2D(p.getX(), p.getY(), 0);
			
			//Generate vector
		    Vect2D newVect = getNewVector(botLocation);      
		    
		    //Update positions array
		    if (positionsPtr < 2) {        
		        positions[positionsPtr] = botLocation;
		        positionsPtr++;
		    } else {
		        //Shift Arr by 1
		        positions[0] = positions[1];                 
		        positions[1] = botLocation;
		    }
		    
		    double targetHeadingRadians = Math.tan(newVect.getY() / newVect.getX());
		    //Convert to degrees
		    targetHeadingRadians = targetHeadingRadians / Math.PI * 180;
		    
		    pilot.rotate((int) -Math.round(targetHeadingRadians - p.getHeading()));
		    pilot.getPilot().forward();
		    isRead = true;
	        
	        emotions.updateBoredom(0.05f);
	        emotions.updateTired(-0.07f);
		} else if (!hasCalled || System.currentTimeMillis() - lastCallback < TIMEOUT) {
			try {
				connection.sendMessage(new SignalStrengthReqMessage());
				hasCalled = true;
				lastCallback = System.currentTimeMillis();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void suppress() {
		this.isRead = true;
		this.hasCalled = false;
		this.pilot.getPilot().stop();
	}

	@Override
	public boolean takeControl() {
		return connection.isConnected() && connection.isRunning() && emotions.getBoredom() <= 0.2f && emotions.getTired() >= 0.8f;
	}

}
