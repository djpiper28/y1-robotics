package behaviours.reactive;

import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.NXTColorSensor;
import lejos.robotics.SampleProvider;
import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;
import utils.Speakers;

public class Music implements Behavior {

	private EV3ColorSensor colourSensor;
	private SampleProvider colourSample;
	
	private static final float colourThreshold = 0.2f;
	
	public Music(EV3ColorSensor colourSensor) {
		this.colourSensor = colourSensor;
	}
	
	@Override
	public void action() {
		// TODO Auto-generated method stub
		this.colourSample = this.colourSensor.getRGBMode();
		float[] rgb = new float[3];
		this.colourSample.fetchSample(rgb, 0);
		if (rgb[0] > colourThreshold) {
			Speakers.beep();
		} else if (rgb[1] > colourThreshold) {
			Speakers.buzz();
		} else if (rgb[2] > colourThreshold) {
			Speakers.descArp();
		}
	}

	@Override
	public void suppress() {
		// TODO Auto-generated method stub
	}

	@Override
	public boolean takeControl() {
		this.colourSample = this.colourSensor.getRGBMode();
		float[] rgb = new float[3];
		this.colourSample.fetchSample(rgb, 0);
		return rgb[0] > colourThreshold || rgb[1] > colourThreshold || rgb[2] > colourThreshold;
	}

}
