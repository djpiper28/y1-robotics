/**
 * @author James
 */
package behaviours.passive;

import lejos.robotics.subsumption.Behavior;
import lejos.utility.Delay;
import utils.Pilot;
import utils.Ruler;
import utils.RubiksCubeInterface;
import emotions.Emotions;
import lejos.utility.Delay;

public class RubiksCubeBehavior implements Runnable {
    private static boolean cubeHasConnected = false;

    private static final float SPEED_INCREASE_PER_TURN = 0.4f;

    private static final int ROTATION_PER_TURN = 30;

    private static final float SOLVE_BORDEM_OFFSET = 0.5f; // make the robot less bored when the cube is solved!

    private static final int MIN_SCRAMBLED_AMOUNT = 20; // minumum amount of moves that need to be made to be able to call the cube scrambled 
    //20 is god's number or the minimum amount of moves to reach any scramble from any state. 

    private static Pilot pilot;

    private static Ruler ruler;

    private static boolean[] running;

    private static Emotions emotions;

    private static boolean remoteControlMode = false;// lets the cube take control over the robot

    private static int sameMoveCount = 0; // when there have been 8 moves that are the same, take control

    private static int highestMovesToSolveSinceSolved = 21; // when the cube is solved, this gets the highest amount of moves to solve it since it has been solved
    // this is to make sure no one can just move the cube L then L' and keep getting points, they have t properly scramble it

    private final static int DELAY = 3000;// the delay between making the robot more bored

    private final static float TICKER = -0.05f;// the amount that the bordem goes down every TICKER ms
    
    private static RubiksCubeInterface lastState = new RubiksCubeInterface(new byte[3]);

    private static float speed = 0.0f;// [0] = forwards/back, [1] = left/right

    public RubiksCubeBehavior(Pilot pilotI, Ruler rulerI, Emotions emotionsI, boolean[] runningI){
        pilot = pilotI;
        ruler = rulerI;
        emotions = emotionsI;
        running = runningI;
    }
    /**
     * 
     * @param data
     * Data format: [0] = Type of message, [1] = rotation code, [2] = moves to solve
     * I hope the data format is like this at least
     */
    public void newCubeData(byte[] data){
        cubeHasConnected = true;
        RubiksCubeInterface cube = new RubiksCubeInterface(data);

        if(cube.getRotationCode() == lastState.getRotationCode()){ // checks if the same move has been made, 8 of the same move puts the robot into remote control move!
            sameMoveCount++;
            if(sameMoveCount >= 8){
                remoteControlMode = !remoteControlMode;
            }
        } else {
            sameMoveCount = 0;
        }
        manageMovement(cube);

        if(cube.getMovesToSolve() == 0 && lastState.getMovesToSolve() != 0 && highestMovesToSolveSinceSolved > MIN_SCRAMBLED_AMOUNT){// if the cube has just been solved
            emotions.updateBoredom(SOLVE_BORDEM_OFFSET);
        } else if(highestMovesToSolveSinceSolved < MIN_SCRAMBLED_AMOUNT){
            if(cube.getMovesToSolve() > highestMovesToSolveSinceSolved){
                highestMovesToSolveSinceSolved = cube.getMovesToSolve();
            }
        }
        lastState = cube;
    }
    private static void manageMovement(RubiksCubeInterface c){ // this converts the cube move into a movement on the robot
        if(remoteControlMode){
            //running[0] = false;
            int move = c.getMove();
            switch(move){// moves: none: 0, forward: 1, back: 2, left: 3, right: 4
            	case 0:
            		break;
                case 1:
                    speed += SPEED_INCREASE_PER_TURN;
                    pilot.setLinearSpeed(speed);
                    if(speed > 0){
                        pilot.getPilot().forward();
                    } else {
                        pilot.getPilot().backward();
                    }
                    break;
                case 2:
                    speed -= SPEED_INCREASE_PER_TURN;
                    pilot.setLinearSpeed(speed);
                    break;
                case 3:
                    pilot.rotate(ROTATION_PER_TURN);
                    break;
                case 4:
                    pilot.rotate(-ROTATION_PER_TURN);
                    break;
            }
        }
    }
    public void run() {
        while (true) { // depreciate the bordem when the cube isn't solved and it's not in RC mode 
			if (!remoteControlMode && lastState.getMovesToSolve() > 0 && cubeHasConnected) {
				emotions.updateBoredom(-0.05f); 
			}
			
			Delay.msDelay(3000);
		}
    }
    public boolean takeControl() {
        return remoteControlMode;
    }
    public void suppress(){
        remoteControlMode = false;
    }
}
