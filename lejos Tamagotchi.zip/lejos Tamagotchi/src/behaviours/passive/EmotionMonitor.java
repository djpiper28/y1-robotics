package behaviours.passive;

import emotions.Emotions;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.NXTSoundSensor;
import lejos.robotics.SampleProvider;
import lejos.utility.Delay;
import utils.Calibrator;

/**
 * 
 * @author John
 *
 */

public class EmotionMonitor implements Runnable {
	
	private Emotions emotions;
	
	private static float EMOTION_DECAY_RATE = -0.05f;
	
	public EmotionMonitor(Emotions emotions) {
		this.emotions = emotions;
	}
	
	/**
	 * All of the emotions go down over time
	 */
	@Override
	public void run() {
		while (true) {
			this.emotions.updateTired(EMOTION_DECAY_RATE);
			this.emotions.updateFear(-EMOTION_DECAY_RATE);
			this.emotions.updateBoredom(EMOTION_DECAY_RATE);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	
}
	

