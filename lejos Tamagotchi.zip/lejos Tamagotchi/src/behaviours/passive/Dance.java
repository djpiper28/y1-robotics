package behaviours.passive;
import utils.Pilot;
import lejos.hardware.Sound;

public class Dance {

	private int interations;
	private Pilot pilot;
	
	public Dance(int iterations, Pilot pilot) {
		this.interations = iterations;
		this.pilot = pilot;
	}
	
	public void start() {
		
		for (int i = 0; i < this.interations; i++) {
			this.pilot.move(50);
			Sound.beep();
			this.pilot.move(-50);
			Sound.beep();
			this.pilot.rotate(900);
			Sound.beep();
			// get some music going maybe when it's dancing			
		}
		
	}
	
}
