package behaviours.passive;
import java.util.Random;

import emotions.Emotions;
import lejos.hardware.lcd.LCD;
import lejos.robotics.subsumption.Behavior;
import utils.Pilot;

/**
 * @author John, James, Antonio
 */
public class Spin implements Behavior {
	
    private int iterations;
	private Pilot pilot;
	private boolean direction;
	private Emotions emotions;
	private static final float boredThreshold = 0.6f;
	
	/**
	 * @param iterations -> Number of times that the robot will spin.
	 * @param pilot -> Pilot class, which controls the movement of the robot.
	 * @param emotions -> Emotions state.
	 */
	public Spin(int iterations, Pilot pilot, Emotions emotions) {
		this.iterations = iterations;
		this.pilot = pilot;
		this.emotions = emotions;
	}
	/**
	 * @return the lowest bound (inclusive) of happiness that must be reached to execute a response in the action() method
	 */
	public static float getThreshold() {
		return boredThreshold;
	}


	@Override
	public boolean takeControl() {
		return (this.emotions.getBoredom() <= boredThreshold);
	}

	/**
	 * The robot will spin in place a number of times,
	 * And will then update its tired values and its boredom levels.
	 */
	@Override
	public void action() {
		for (int i = 0; i < this.iterations; i++) {
			direction = !direction;
			this.pilot.rotate(direction ? -900 : 900);
		}
		this.emotions.updateTired(-0.1f);
		this.emotions.updateBoredom(0.5f);
	}

	@Override
	public void suppress() {
		pilot.stop();
	}
}
