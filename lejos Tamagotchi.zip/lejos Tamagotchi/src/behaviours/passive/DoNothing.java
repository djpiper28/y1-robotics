package behaviours.passive;

import behaviours.reactive.FearResponder;
import emotions.Emotions;
import lejos.hardware.Button;
import lejos.hardware.lcd.LCD;
import lejos.robotics.subsumption.Behavior;
import utils.Pilot;
import utils.Ruler;

public class DoNothing implements Behavior {
	
	static boolean nothing = true;
	private Emotions emotions;
	
	public DoNothing(Emotions emotions) {
		this.emotions = emotions;
	}

	@Override
	public boolean takeControl() {
		if (this.emotions.getHappiness() >= Spin.getThreshold() || this.emotions.getFear() >= FearResponder.getThreshold()) {
			nothing = false;
		} else {
			nothing = true;
		}
		
		//if (Button.ENTER.isDown()) return false;
		return nothing;
	}

	@Override
	public void action() {

	}

	@Override
	public void suppress() {
		nothing = false;

	}

}
