/**
 * 
 */
package behaviours.passive;

import java.io.IOException;

import emotions.Emotions;
import lejos.hardware.Battery;
import lejos.hardware.Button;
import lejos.robotics.subsumption.Behavior;
import spaghetti.netty.RobotBtConnection;

/**
 * @author danny
 * @version 1.0
 */
public class ExitBehavior implements Behavior {

	private RobotBtConnection connection;
	private Emotions emotions;
	
	/**
	 * @since 1.0
	 */
	public ExitBehavior(RobotBtConnection connection) {
		this.connection = connection;
	}

	@Override
	public void action() {
		this.connection.stopPollingThread();
		
		try {
			this.connection.disconnect();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.exit(0);
	}

	@Override
	public void suppress() {

	}

	@Override
	public boolean takeControl() {
		return Battery.getVoltage() < Emotions.MINIMUM_VOLTAGE || Button.ESCAPE.isDown();
	}

}
