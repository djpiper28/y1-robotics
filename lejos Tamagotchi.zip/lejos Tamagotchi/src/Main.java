
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import behaviours.passive.DoNothing;
import behaviours.passive.Spin;
import behaviours.passive.EmotionMonitor;
import behaviours.passive.RubiksCubeBehavior;
import behaviours.passive.ExitBehavior;
import behaviours.reactive.ChaseBehavior;
import behaviours.reactive.FearResponder;
import behaviours.reactive.Music;
import behaviours.reactive.ScareMonitor;
import behaviours.reactive.TiredBehavior;
import behaviours.reactive.Wave;
import emotions.Emotions;
import graphics.ImageDrawer;
import lejos.hardware.Button;
import lejos.hardware.lcd.LCD;
import lejos.hardware.port.Port;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.hardware.sensor.EV3UltrasonicSensor;
import lejos.hardware.sensor.NXTColorSensor;
import utils.Pilot;
import utils.Ruler;
import utils.Speakers;
import lejos.robotics.SampleProvider;
import lejos.robotics.subsumption.Arbitrator;
import lejos.robotics.subsumption.Behavior;
import spaghetti.netty.OnSigStrengthRecv;
import spaghetti.netty.RobotBtConnection;
import behaviours.reactive.Wave;

/**
 * 
 * @author John, Danny
 * @version 1.0
 */
public class Main {

	private static Emotions emotions = new Emotions();
	private static ImageDrawer drawer;
	private static Pilot pilot = new Pilot();
	private static Ruler ruler = new Ruler(SensorPort.S3);
	private static EV3ColorSensor colourSensor = new EV3ColorSensor(SensorPort.S2);
	private static RobotBtConnection conn;
	private static final String version = "v1.0.0";

	private static void extractSoundFilesFromJar () {
		Scanner reader = new Scanner(Main.class.getClassLoader().getResourceAsStream("resManifest"));
		while (reader.hasNextLine()) {
			String name = reader.nextLine();
			File file = new File(name);
			if(!file.exists()) {
				try {
					DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
					DataInputStream dis = new DataInputStream(Main.class.getClassLoader().getResourceAsStream(name));
					
					byte[] bytes = dis.readAllBytes();
					for (int i = 0; i < bytes.length; i++)
						dos.writeByte(bytes[i]);
					
					dos.flush();
					dos.close();
					dis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		reader.close();
	}
	
	public static void main(String[] args) {
		extractSoundFilesFromJar();
		
		//Print version and names
		LCD.drawString(String.format("Tamagotchi version %s", version), 0, 0);
		
		String[] authors = {"Antonio", "Danny", "James", "John"};
		for (int i = 0; i < authors.length; i++)	
			LCD.drawString(authors[i], 0, 1 + i);

		Button.ENTER.waitForPressAndRelease();
		LCD.clear();
		
		// This snippet is from
		// https://github.com/cyclingProfessor/LejosExamples/blob/master/PC-Connection/EV3Mapper.java
		int ip_addr = 2;
		LCD.drawString("Insert the IP from the app", 0 ,0);
		LCD.drawString("Then press enter to confirm", 0, 1);
		LCD.drawString("          ^", 0, 3);
		LCD.drawString("IP 10.0.1." + ip_addr + "   ", 0, 4);
		LCD.drawString("          v", 0, 5);
		
		int id = Button.waitForAnyPress();
		while (id != Button.ID_ENTER) {
			switch (id) {
			case Button.ID_UP:
				ip_addr++;
				break;
			case Button.ID_DOWN:
				ip_addr--;
				break;
			}
			
			ip_addr = Math.min (254, ip_addr);
			ip_addr = Math.max (1, ip_addr);
			
			LCD.drawString("IP 10.0.1." + ip_addr + "   ", 0, 4);
			id = Button.waitForAnyPress();
		}
		
		LCD.clear();

		final boolean[] running = { true };

		RubiksCubeBehavior cube = new RubiksCubeBehavior(pilot, ruler, emotions, running);
		Thread CubeThread = new Thread(cube);
		CubeThread.start();
		// we have to define the cube behavior up here so the bt connection can be passed it without it having to be global
		
		conn = new RobotBtConnection(emotions, "10.0.1." + ip_addr, cube);
		emotions.setNetty(conn);

		Speakers.loadSettings();

		ScareMonitor spookySensor = new ScareMonitor(emotions, SensorPort.S1, 0.7f);
		Thread ScareThread = new Thread(spookySensor);
		ScareThread.start();

		EmotionMonitor emotionMonitor = new EmotionMonitor(emotions);
		Thread EmotionThread = new Thread(emotionMonitor);
		EmotionThread.start();

		Wave wave = new Wave(emotions, ruler, pilot);
		Thread distanceThread = new Thread(wave);
		distanceThread.start();
		
		Thread cubeThread = new Thread(cube);
		cubeThread.start();

		FearResponder fearResponder = new FearResponder(emotions, pilot, ruler);
		Spin spin = new Spin(3, pilot, emotions);
		TiredBehavior tiredBehavior = new TiredBehavior(emotions);
		final ChaseBehavior chase = new ChaseBehavior(conn, pilot, emotions);
		Music musicBehavior = new Music(colourSensor);
		
		conn.setOnSig(new OnSigStrengthRecv() {
			@Override
			public void onSignalStrength(double strength) {
				chase.setSignal(strength);
			}
		});
		
		ExitBehavior exitBehavior = new ExitBehavior(conn);
		
		Behavior[] behaviors = { spin, tiredBehavior, fearResponder, chase, musicBehavior, exitBehavior };
		Arbitrator arbitrator = new Arbitrator(behaviors);
		arbitrator.go();
	}

	public static void writeEmotions() throws IOException {

		BufferedWriter write = new BufferedWriter(new FileWriter("emotions.txt"));
		write.write(emotions.getBoredom() + "\n");
		write.write(emotions.getTired() + "\n");
		write.write(emotions.getFear() + "");

		write.close();

	}

}
