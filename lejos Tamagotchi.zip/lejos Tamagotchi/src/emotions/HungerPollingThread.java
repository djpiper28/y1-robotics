package emotions;
/**
 * This class will poll the emotion.setHunger method every minute
 * which will update the hunger value to the battery value.
 * @author danny
 * @version 1.0
 */
public final class HungerPollingThread implements Runnable {

	private final long FREQUENCY = 60l * 1000l;
	private final Emotions parent;
	private boolean[] running;
	
	/**
	 * This constructor set up the thread but <b>NOT</b> start it
	 * @param Emotions parent this is the object to poll.
	 * @since 1.0
	 */
	public HungerPollingThread(Emotions parent) {
		this.parent = parent;
		this.running = new boolean[1];
	}
	
	/**
	 * This method will start the deamon thread and throw an exception
	 * if the thread has already started.
	 * @since 1.0
	 */
	public void start() {
		if (this.running[0]) {
			throw new IllegalStateException("Thread already started.");
		}
		
		this.running[0] = true;
		Thread thread = new Thread(this, "Polling thread.");
		thread.setDaemon(true);
		thread.start();
	}
	
	/**
	 * This method will stop the thread if it is running.
	 * @since 1.0
	 */
	public void stop() {
		this.running[0] = false;
	}
	
	/**
	 * This is the runnable which polls the emotions object.
	 * Maybe it should be encapulsated so that it cannot be 
	 * accidently called.
	 * @since 1.0
	 */
	@Override
	public void run() {
		while (running[0]) {
			long last = System.currentTimeMillis();
			
			while (System.currentTimeMillis() - last <= FREQUENCY && running[0]) {
				Thread.yield();
				try {
					Thread.sleep(1000l);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			this.parent.updateHunger();
		}
	}

}
