package emotions;
import java.io.IOException;

import common.EmotionPrimitiveID;
import common.EmotionsInterface;
import common.netty.messages.EmotionUpdateMessage;
import common.netty.messages.MessagesIOHandler;
import common.netty.messages.NotifyUserMessage;
import common.netty.messages.UserNotification;
import lejos.hardware.Battery;
import lejos.hardware.lcd.LCD;


/** Emotions class is what is going to determine most actions
 *  about the robot, it will calculate what mood it is in depending on certain factors,
 *  including hunger, play time and other things.
 * @author John
 * @version 1.3
 * @see EmotionsInterface
 * */

public class Emotions extends EmotionsInterface {
	
	private final static float MAXIMUM_VOLTAGE = 9f;
	public final static float MINIMUM_VOLTAGE = 6.2f; // not sure about this
	
	private MessagesIOHandler netty;	
	private final HungerPollingThread pollingThread; 
	private boolean hungerNotifSent, tiredNotifSent, fearNotifSent, BoredemNotifSent;
	
	/**
	 * Sets every value to 0, apart from hunger which is determined on battery power.
	 * Calculates overall emotion.
	 */
	public Emotions() {
		super();
		this.updateHunger();
		
		this.pollingThread = new HungerPollingThread(this);
		this.pollingThread.start();
		
		this.hungerNotifSent = false;
		this.tiredNotifSent = false;
		this.fearNotifSent = false;
		this.BoredemNotifSent = false;
	}
		
	public void setNetty(MessagesIOHandler netty) {
		this.netty = netty;
	}
	
	/**
	 * This method should be called every minute, not sure how to implement yet.
	 */
	public void updateHunger() {
		float preHunger = super.getHunger();
		int voltageLevel = Battery.getVoltageMilliVolt();
		this.setHunger((voltageLevel-MINIMUM_VOLTAGE) / (MAXIMUM_VOLTAGE-MINIMUM_VOLTAGE));
		updateTired((super.getHunger() - preHunger) / 2); //Raises tiredness by half change in hunger
	}
	
	/**
	 * @param offset -> A float value to increase (or decrease) the boredom
	 * -1 <= offset <= 1
	 * A positive value will increase boredom
	 * @since 1.0
	 */	
	public void updateBoredom(float offset) {
		super.setBoredem(this.getBoredom() + offset);
	}
	
	/**
	 * @param offset -> A float value to increase (or decrease) the "tired"
	 * -1 <= offset <= 1
	 * A positive value will increase "tired"
	 * @since 1.0
	 */
	public void updateTired(float offset) {
		super.setTired(this.getTired() + offset);
	}
		
	/**
	 * @param offset -> A float value to increase (or decrease) the "fear"
	 * -1 <= offset <= 1
	 * A positive value will increase "tired"
	 * @since 1.0
	 */
	public void updateFear(float offset) {
		super.setFear(this.getFear() + offset);		
	}

	@Override
	public void onHappinessSet(float newHappiness) {
	}

	@Override
	public void onCourageSet(float newCourage) {
		
	}
	
	@Override
	public void onCuriositySet(float newCuriosity) {
		
	}
	
	@Override
	public void onHungerSet(float newHunger) {
		if (netty != null) {
			try {
				this.netty.sendMessage(
						new EmotionUpdateMessage(EmotionPrimitiveID.HUNGER,
								newHunger));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			if (newHunger < 0.5f) {
				if (!this.hungerNotifSent) {
					try {
						this.netty.sendMessage(
								new NotifyUserMessage(new UserNotification("Your tamgotchi is hungry!", "Please charge your poor EV3.")));
						this.hungerNotifSent = true;
					} catch (IOException e) {
						e.printStackTrace();
					}
				}				 
			} else {
				this.hungerNotifSent = false;
			}
		}
	}

	@Override
	public void onBordemSet(float newBoredom) {
		if (netty != null) {
			try {
				this.netty.sendMessage(
						new EmotionUpdateMessage(EmotionPrimitiveID.BOREDOM,
												 newBoredom));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			if (newBoredom < 0.5f) {
				if (!this.BoredemNotifSent) {
					try {
						this.netty.sendMessage(
								new NotifyUserMessage(new UserNotification("Your tamgotchi is bored!", "Please play with it so that it stops being bored.")));
						this.BoredemNotifSent = true;
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} else {
				this.BoredemNotifSent = false;
			}
		}
	}

	@Override
	public void onTiredSet(float newTired) {
		if (netty != null) {
			try {
				this.netty.sendMessage(
						new EmotionUpdateMessage(EmotionPrimitiveID.TIRED,
								newTired));
			} catch (IOException e) {
				e.printStackTrace();
			}

			if (newTired < 0.5f) {
				if (!this.tiredNotifSent) {
					try {
						this.netty.sendMessage(
								new NotifyUserMessage(new UserNotification("Your tamgotchi is tired!", "Please play with it so that it wakes up a bit.")));
						this.tiredNotifSent = true;
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} else {
				this.tiredNotifSent = false;
			}
		}
	}

	@Override
	public void onFearSet(float newFear) {
		if (netty != null) {
			try {
				this.netty.sendMessage(
						new EmotionUpdateMessage(EmotionPrimitiveID.FEAR,
								newFear));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			if (newFear < 0.5f) {
				if (!this.fearNotifSent) {
					try {
						this.netty.sendMessage(
								new NotifyUserMessage(new UserNotification("Your tamgotchi is scared!", 
										"Please be quieter to stop them from being so scared.")));
						this.fearNotifSent = true;
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} else {
				this.fearNotifSent = false;
			}
		}
	}
		
}
