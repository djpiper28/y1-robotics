import os
 
files = os.listdir("resources/")
 
f = open ("resources/resManifest", "w+")
for file_ in files:
    if len(file_.split(".wav")) > 1:
        f.write(file_+"\n")
         
f.close()
