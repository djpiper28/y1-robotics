package uk.co.rhul.r14.letamagotchijos.min2phase;

public class source {
    //https://github.com/cs0x7f/min2phase i think
}
