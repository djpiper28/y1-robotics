# Tamagotchi

# Compiling and testing the program
`ant jar` to make a jar in `dist/` for the robot.
`ant junit` to run the junit tests.
