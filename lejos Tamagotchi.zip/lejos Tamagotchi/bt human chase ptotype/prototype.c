#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <sys/types.h> 
#include <pthread.h>

//GTK includes
#include <gtk/gtk.h>

// Maths to support sim
struct vect2DMag {
    double x, y, magnitude;
};

struct vect2DArr {
    struct vect2DMag *arr;
    int len;
};

double sqr(double a) {
    return a * a;
}

//Used in the robot implementation and gives an aprox distance
/*double signalStrToDist(double signalStr) {
    return 1 / (signalStr * signalStr);
}*/

double vect2Ddist(struct vect2DMag a, struct vect2DMag b) {
    return sqrt(sqr(a.x - b.x) + sqr(a.y - b.y));
}

#define DETERMINANT sqr(b) - (4 * a * c)
int detGrtEqZero(double a, double b, double c) {
    return DETERMINANT >= 0;
}

double quadraticUp(double a, double b, double c) {
    return (-b + sqrt(DETERMINANT)) / (2 * a);
}

double quadraticLow(double a, double b, double c) {    
    return (-b - sqrt(DETERMINANT)) / (2 * a);
}

double XforY(double y, double c, double m) {
    return (y - c) / m;
}

#define CIRCLE_A 1
#define CIRCLE_B -2 * a
#define CIRCLE_C sqr(a) + sqr(y) - 2 * b * y + sqr(b) - sqr(r)

double circleXUp(double y, double a, double b, double r) {
    return quadraticUp(CIRCLE_A, CIRCLE_B, CIRCLE_C);
}

double circleXLow(double y, double a, double b, double r) {
    return quadraticLow(CIRCLE_A, CIRCLE_B, CIRCLE_C);
}

//To account for double inaccuracies
#define THRESHOLD 0.001

struct vect2DArr intersect(struct vect2DMag a, struct vect2DMag b) {    
    //output.arr needs to be freed after it has been used.
    struct vect2DArr output = {malloc(sizeof(struct vect2DMag) * 2), 0};
    double centreDist = vect2Ddist(a, b);
    
    a.magnitude = fabs(a.magnitude);
    b.magnitude = fabs(b.magnitude);
    double sumRadii = a.magnitude + b.magnitude;
    
    //Case 0 - 2 intersections (the same as case 1, but case 1 can get away with 
    //less maths so has less run time and is better for the ev3 as such)
    if (centreDist > THRESHOLD && fabs(a.magnitude - b.magnitude) < centreDist 
                                                     && centreDist < sumRadii) {
        double psi = sqr(b.x) + sqr(b.y) + sqr(a.magnitude) 
                   - sqr(b.magnitude) - sqr(a.x) - sqr(a.y);
        double phi = 2 * a.y - 2 * b.y;
        double omega = 2 * b.x - 2 * a.x;
        
        //y^2 coeff
        double aa = 1 + sqr(phi / omega);                  
        //y^1 coeff
        double bb = 2 * (psi * phi) / sqr(omega) - 2 * a.x * (phi / omega) 
                  - 2 * a.y;
        //y^0 coeff
        double cc = sqr(psi / omega) - 2 * a.x * (psi / omega) + sqr(a.x) 
                  + sqr(a.y) - sqr(a.magnitude);
        
        //Check for real solutions
        //The solutions will be real as the first if ensures that the circles
        //match this case
        if (detGrtEqZero(aa, bb, cc)) {
            double intYA = quadraticUp(aa, bb, cc);
            double intYB = quadraticLow(aa, bb, cc);
            
            //solve for x
            double xForA[4];
            xForA[0] = circleXUp(intYA, a.x, a.y, a.magnitude);
            xForA[1] = circleXLow(intYA, a.x, a.y, a.magnitude);
            
            xForA[2] = circleXUp(intYB, a.x, a.y, a.magnitude);
            xForA[3] = circleXLow(intYB, a.x, a.y, a.magnitude);
            
            double xForB[4];
            xForB[0] = circleXUp(intYA, b.x, b.y, b.magnitude);
            xForB[1] = circleXLow(intYA, b.x, b.y, b.magnitude);
            
            xForB[3] = circleXUp(intYB, b.x, b.y, b.magnitude);
            xForB[4] = circleXLow(intYB, b.x, b.y, b.magnitude);
            
            printf("y1 =%f\n", intYA);
            printf("y2 =%f\n", intYB);
            for (int i = 0; i < 4; i++)
                printf("x1 = %f\n", xForA[i]);
            
            for (int i = 0; i < 4; i++)
                printf("x2 =%f\n", xForB[i]);
            
            int ptr = 0;            
            for (int i = 0; i < 2 && ptr < 2; i++) {
                for (int j = 0; j < 2 && ptr < 2; j++) {
                    if (fabs(xForA[i] - xForB[j]) < THRESHOLD) {
                        struct vect2DMag vect = {xForA[i], intYA, 0};
                        
                        output.arr[ptr] = vect;
                        ptr++;
                        
                        printf("Solution %d :%f, %f\n", ptr, vect.x, vect.y);
                    }
                }
            }
            
            for (int i = 2; i < 4 && ptr < 2; i++) {
                for (int j = 2; j < 4 && ptr < 2; j++) {
                    if (fabs(xForA[i] - xForB[j]) < THRESHOLD) {
                        struct vect2DMag vect = {xForA[i], intYB, 0};
                        
                        output.arr[ptr] = vect;
                        ptr++;
                        
                        printf("Solution %d :%f, %f\n", ptr, vect.x, vect.y);
                    }
                }
            }
            
            output.len = ptr;
        } else {
            printf("OOF OUCH Invalid circles.\n");
        }
        
        printf("Case 0: Returned %d intersections\n", output.len);        
    }
    
    //Case 1 - 1 intersection
    else if (fabs(centreDist - sumRadii) < THRESHOLD) {        
        struct vect2DMag vect = {a.x + ((b.x - a.x) * (a.magnitude / sumRadii)),
            a.y + ((b.y - a.y) * (a.magnitude / sumRadii)),
            0};
            output.arr[0] = vect;
            output.len = 1;
            
            printf("Case 1: Returned single intersection\n");
    }
    
    //Case 2 they are in the same location
    else if (centreDist < THRESHOLD) {
        struct vect2DMag vect = {0, 0, 0};
        output.arr[0] = vect;
        output.len = 1;
        
        printf("Case 2: At signal location => 0,0 vector\n");
    } 
    
    //Case 3 no intersections - get aprox using radii mid points
    else {
        struct vect2DMag vect;
        if (a.magnitude < b.magnitude) {
            vect = a;
        } else {
            vect = b;
        }
        
        vect.x += 0.01;
        vect.y += 0.01;
        
        output.arr[0] = vect;
        output.len = 1;
        
        printf("Case 3: Vector to lowest signal point\n");
    } 
    
    return output;
}

struct vect2DMag getNewVector(struct vect2DMag *positions, int len, 
                              struct vect2DMag currentPos) {
    //Get new direction vector        
    if (len == 0) {
        struct vect2DMag vectA = {rand(), rand(), 0};
        printf("Returned random vector.\n");
        return vectA;
    } else if (len == 1) {
        struct vect2DArr vects = intersect(positions[0], currentPos);
        struct vect2DMag vect = vects.arr[0];
        vect.x -= currentPos.x;
        vect.y -= currentPos.y;
        printf("Returned vector of current pos to an intersection.\n");
        
        free(vects.arr);
        return vect;
    } else {
        //Get intersections      
        struct vect2DArr vects01 = intersect(positions[1], currentPos);
        struct vect2DArr vects12 = intersect(positions[0], positions[1]);
        
        //Get closest two points 
        int changedFlag = 0;
        double minD;
        struct vect2DMag vectA;
        struct vect2DMag vectB;
        
        for (int aCnt = 0; aCnt < vects01.len; aCnt++) {
            for (int bCnt = 0; bCnt < vects12.len; bCnt++) {
                double d = vect2Ddist(vects01.arr[aCnt], vects12.arr[bCnt]);
                if (d < minD || !changedFlag) {
                    minD = d;
                    changedFlag = 1;
                    
                    vectA = vects01.arr[aCnt];
                    vectB = vects12.arr[bCnt];
                    
                    printf("Position vectors of (%f, %f) and (%f, %f) considered\n", 
                           vectA.x, vectA.y, vectB.x, vectB.y);
                }
                   
                printf("Position vectors of (%f, %f) and (%f, %f) NOT considered\n", 
                           vectA.x, vectA.y, vectB.x, vectB.y);            
            }
        }
        
        free(vects01.arr);        
        free(vects12.arr);
        
        //Get midpoint
        struct vect2DMag vectC = {(vectA.x + vectB.x) / 2, 
                                  (vectA.y + vectB.y) / 2, 
                                  0};
        
        //Get get vector of midpoint - robotPos        
        vectC.x -= currentPos.x;
        vectC.y -= currentPos.y;    
        
        printf("Returned vector of current pos to the midpoint of closest two intersections.\n");
        return vectC;
    }
}






// GUI and sim logic

static cairo_surface_t *surface = NULL; //Canvas

//Cairo method from https://developer.gnome.org/gtk4/unstable/ch01s04.html
//Clear surface
static void clear_surface (void) {
    cairo_t *cr;
    
    cr = cairo_create (surface);
    
    cairo_set_source_rgb (cr, 1, 1, 1);
    cairo_paint (cr);
    
    cairo_destroy (cr);
}

/* Redraw the screen from the surface. Note that the draw
 * callback receives a ready-to-be-used cairo_t that is already
 * clipped to only draw the exposed areas of the widget
 */
static void draw_cb (GtkDrawingArea *drawing_area,
         cairo_t        *cr,
         int             width,
         int             height,
         gpointer        data) {
    cairo_set_source_surface (cr, surface, 0, 0);
    cairo_paint (cr);
}

//Draw a rect from x1, y1 to x2, y2
static void draw (GtkWidget *widget, double x1, double y1, double x2, double y2, 
                  double r, double g, double b) {
    cairo_t *cr;
    
    /* Paint to the surface, where we store our state */
    cr = cairo_create (surface);
    
    cairo_set_source_rgb (cr, r, g, b);
    cairo_rectangle (cr, x1, y1, x2, y2);
    cairo_fill (cr);
    
    cairo_destroy (cr);
    
    /* Now invalidate the drawing area. */
    gtk_widget_queue_draw (widget);
}

static void close_window (void) {
    if (surface)
        cairo_surface_destroy (surface);
}

#define WIDTH 800
#define SPEED 25
#define BOT_WIDTH 20
#define DEFAULT_BOT {WIDTH / 4, WIDTH / 2, 0}
#define DEFAULT_SIGNAL {3 * WIDTH / 4, WIDTH / 2, 0}
#define DEFAULT_VECT {1, 1, 0}

static GtkWidget *drawing_area;
static pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
static int step = 0, 
           posLen = 0;
struct vect2DMag botLocation = DEFAULT_BOT,
                 signalLocation = DEFAULT_SIGNAL,
                 botMvVector = DEFAULT_VECT,
                *positions;

void drawFrame() {
    double d = sqrt(sqr(botMvVector.x) + sqr(botMvVector.y));
    struct vect2DMag normalisedVector = {botMvVector.x / d, botMvVector.y /d, 0};
    
    clear_surface();
    
    //Draw robot as a square
    draw(drawing_area, botLocation.x - BOT_WIDTH / 2, 
         botLocation.y - BOT_WIDTH / 2,
         BOT_WIDTH, BOT_WIDTH, 1, 0, 0);
    
    //Draw a line that is its vector of movement
    for (int i = 0; i < 100; i++) {
        int a = round(i * normalisedVector.x + botLocation.x);
        int b = round(i * normalisedVector.y + botLocation.y);
        
        draw(drawing_area, a - 1, b - 1, 2, 2, 0, 0, 0);
    }
    
    //Draw line from bot to signal
    double x = signalLocation.x - botLocation.x;
    double y = signalLocation.y - botLocation.y;
    d = sqrt(sqr(x) + sqr(y));
    struct vect2DMag normalisedVector2 = {x / d, y /d, 0};
    
    for (int i = 0; i < round(d); i++) {
        int a = round(i * normalisedVector2.x + botLocation.x);
        int b = round(i * normalisedVector2.y + botLocation.y);
        
        draw(drawing_area, a - 1, b - 1, 2, 2, 0, 0, 1);
    }
    
    //Draw the signal as a square
    draw(drawing_area, signalLocation.x - BOT_WIDTH / 2,
         signalLocation.y - BOT_WIDTH / 2,
         BOT_WIDTH, BOT_WIDTH, 0, 0, 1);
}

// Create a new surface of the appropriate size to store our scribbles
static void resize_cb (GtkWidget *widget,
                       int        width,
                       int        height,
                       gpointer   data) {
    if (surface) {
        cairo_surface_destroy (surface);
        surface = NULL;
    }
    
    if (gtk_native_get_surface (gtk_widget_get_native (widget))) {
        surface = gdk_surface_create_similar_surface (gtk_native_get_surface( gtk_widget_get_native (widget)), CAIRO_CONTENT_COLOR,
            gtk_widget_get_width (widget), gtk_widget_get_height (widget));
        
        /* Initialize the surface to white */
        clear_surface();
    }
    
    drawFrame();
}

void resetSim_() {    
    pthread_mutex_lock(&mutex);   
    printf("Sim reset at step %d.\n", step);
    
    step = 0;
    posLen = 0;
    
    struct vect2DMag a = DEFAULT_BOT;
    botLocation = a;
    
    struct vect2DMag b = DEFAULT_SIGNAL;
    signalLocation = b;
    
    struct vect2DMag c = DEFAULT_VECT;
    botMvVector = c;
    
    drawFrame();
    
    pthread_mutex_unlock(&mutex);
}

//Keep in the canvas
void bindPosVect(struct vect2DMag *a) {
    if (a->x < 0) {
        a->x = 0;       
    }
    
    else if (a->x > WIDTH) {
        a->x = WIDTH;
    }
    
    if (a->y < 0) {
        a->y = 0;       
    }
    
    else if (a->y > WIDTH) {
        a->y = WIDTH;
    }
}

static double start_x;
static double start_y;

static void drag_begin_signal (GtkGestureDrag *gesture,
            double          x,
            double          y,
            GtkWidget      *area) {
    start_x = x;
    start_y = y;
    
    signalLocation.x = start_x;
    signalLocation.y = start_y;    
    bindPosVect(&signalLocation);
    
    drawFrame();
}
static void drag_update_signal (GtkGestureDrag *gesture,
             double          x,
             double          y,
             GtkWidget      *area) {
    signalLocation.x = start_x + x;
    signalLocation.y = start_y + y;
    bindPosVect(&signalLocation);
    
    drawFrame();
}

static void drag_end_signal (GtkGestureDrag *gesture,
          double          x,
          double          y,
          GtkWidget      *area) {
    signalLocation.x = start_x + x;
    signalLocation.y = start_y + y;
    bindPosVect(&signalLocation);
    
    drawFrame();
}

static void drag_begin_bot (GtkGestureDrag *gesture,
            double          x,
            double          y,
            GtkWidget      *area) {
    start_x = x;
    start_y = y;
    
    botLocation.x = start_x;
    botLocation.y = start_y;    
    bindPosVect(&botLocation);
    
    drawFrame();
}
static void drag_update_bot (GtkGestureDrag *gesture,
             double          x,
             double          y,
             GtkWidget      *area) {
    botLocation.x = start_x + x;
    botLocation.y = start_y + y;
    bindPosVect(&botLocation);
    
    drawFrame();
}

static void drag_end_bot (GtkGestureDrag *gesture,
          double          x,
          double          y,
          GtkWidget      *area) {
    botLocation.x = start_x + x;
    botLocation.y = start_y + y;
    bindPosVect(&botLocation);
    
    drawFrame();
}

static void pressed (GtkGestureClick *gesture,
         int              n_press,
         double           x,
         double           y,
         GtkWidget       *area) {
    drawFrame();
}

void stepSim(GtkWidget *widget, gpointer data) {
    pthread_mutex_lock(&mutex);    

    //Generate vector
    struct vect2DMag newVect = getNewVector(positions, posLen, botLocation);    
    
    double d = sqrt(sqr(newVect.x) + sqr(newVect.y));
    struct vect2DMag normalisedVector = {newVect.x / d, newVect.y /d, 0};
    
    botMvVector.x = normalisedVector.x * SPEED;
    botMvVector.y = normalisedVector.y * SPEED;
    
    //Update positions array
    if (posLen < 2) {        
        positions[posLen] = botLocation;
        posLen++;

        printf("At step %d, poslen is %d and a new item is put in the pos array.\n",
               step, posLen);
    } else {
        //Shift Arr by 1
        positions[0] = positions[1];                 
        positions[1] = botLocation;
        
        printf("At step %d, pos array is full so shifted then a new item added to the end.\n",
               step);
    }
    
    //Move bot
    botLocation.x += botMvVector.x;
    botLocation.y += botMvVector.y;
    
    bindPosVect(&signalLocation);
    bindPosVect(&botLocation);
    botLocation.magnitude = vect2Ddist(botLocation, signalLocation);
    
    printf("At step %d, the bot is moved to (%f, %f) with vector (%f, %f)\n",
           step, botLocation.x, botLocation.y, botMvVector.x, botMvVector.y);
    
    drawFrame();
    
    step++;
    
    printf("\n\n");
    pthread_mutex_unlock(&mutex);
}

void resetSim(GtkWidget *widget, gpointer data) {
    resetSim_();
}

static void activate (GtkApplication *app,
          gpointer        user_data) {
    positions = (struct vect2DMag *) malloc(sizeof(struct vect2DMag) * 2);
    if (positions == NULL)
        exit(13);
    
    GtkWidget *window;    
    window = gtk_application_window_new (app);
    gtk_window_set_title (GTK_WINDOW (window), "Human Chase Mode Prototype");
    gtk_window_set_resizable(GTK_WINDOW (window), 0); //Disable resizing as I am lazy
    g_signal_connect (window, "destroy", G_CALLBACK (close_window), NULL);
        
    //Box container
    GtkWidget *box;    
    box = gtk_box_new (GTK_ORIENTATION_VERTICAL, 0);
    gtk_window_set_child (GTK_WINDOW (window), box);    
    
    //Step sim button
    GtkWidget *step;
    step = gtk_button_new_with_label ("Step Simulation");
    g_signal_connect (step, "clicked", G_CALLBACK (stepSim), NULL);
    gtk_box_append (GTK_BOX (box), step);
    
    //Canvas
    drawing_area = gtk_drawing_area_new();
    gtk_box_append (GTK_BOX (box), drawing_area);        
    gtk_widget_set_size_request (drawing_area, WIDTH, WIDTH);
    gtk_drawing_area_set_draw_func (GTK_DRAWING_AREA (drawing_area), draw_cb, NULL, NULL);    
    g_signal_connect_after (drawing_area, "resize", G_CALLBACK (resize_cb), NULL);
    
    //Add drag listeners to move signal
    GtkGesture *drag;
    
    drag = gtk_gesture_drag_new();
    gtk_gesture_single_set_button (GTK_GESTURE_SINGLE (drag), GDK_BUTTON_PRIMARY);
    gtk_widget_add_controller (drawing_area, GTK_EVENT_CONTROLLER (drag));
    g_signal_connect (drag, "drag-begin", G_CALLBACK (drag_begin_signal), drawing_area);
    g_signal_connect (drag, "drag-update", G_CALLBACK (drag_update_signal), drawing_area);
    g_signal_connect (drag, "drag-end", G_CALLBACK (drag_end_signal), drawing_area);
    
    
    GtkGesture *dragBot;
    dragBot = gtk_gesture_drag_new();
    gtk_gesture_single_set_button (GTK_GESTURE_SINGLE (dragBot), GDK_BUTTON_SECONDARY);
    gtk_widget_add_controller (drawing_area, GTK_EVENT_CONTROLLER (dragBot));
    g_signal_connect (dragBot, "drag-begin", G_CALLBACK (drag_begin_bot), drawing_area);
    g_signal_connect (dragBot, "drag-update", G_CALLBACK (drag_update_bot), drawing_area);
    g_signal_connect (dragBot, "drag-end", G_CALLBACK (drag_end_bot), drawing_area);
        
    //Reset sim button
    GtkWidget *reset;
    reset = gtk_button_new_with_label ("Reset Simulation");
    g_signal_connect (reset, "clicked", G_CALLBACK (resetSim), NULL);
    gtk_box_append (GTK_BOX (box), reset);    
    
    gtk_window_present (GTK_WINDOW (window));
}

int main(int argc, char **argv) {
    //Start gtk gui
    srand((unsigned) time(NULL));
    GtkApplication *app;
    int status;
    
    app = gtk_application_new ("danny.piper.prototype", G_APPLICATION_FLAGS_NONE);
    g_signal_connect (app, "activate", G_CALLBACK (activate), NULL);
    status = g_application_run (G_APPLICATION (app), argc, argv);
    g_object_unref (app);
    
    if (positions != NULL)
        free(positions);
    
    return status;    
} 
